package com.sonet.assistant.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val triggerType: String = "time", // time, recurring, location, on_command
    val scheduleTimeMillis: Long = 0L,
    val isRecurring: Boolean = false,
    val recurringCronOrPattern: String = "",
    val status: String = "ACTIVE", // ACTIVE, PAUSED, COMPLETED
    val createdAt: Long = System.currentTimeMillis(),
    val lastRun: Long = 0L,
    val result: String = ""
)
