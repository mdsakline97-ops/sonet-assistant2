package com.sonet.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonet.assistant.R
import com.sonet.assistant.data.db.entity.ConversationEntity
import com.sonet.assistant.data.model.AssistantState
import com.sonet.assistant.service.SonetForegroundService
import com.sonet.assistant.ui.components.MicWaveformAnimation
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.PurpleAccent
import com.sonet.assistant.ui.theme.SurfaceDark
import kotlinx.coroutines.flow.Flow

@Composable
fun HomeScreen(
    recentConversationsFlow: Flow<List<ConversationEntity>>,
    onMicClicked: () -> Unit,
    onQuickCommand: (String) -> Unit
) {
    val assistantState by SonetForegroundService.assistantStateFlow.collectAsState()
    val lastUserSpeech by SonetForegroundService.lastUserSpeechFlow.collectAsState()
    val lastAssistantSpeech by SonetForegroundService.lastAssistantSpeechFlow.collectAsState()
    val recentConversations by recentConversationsFlow.collectAsState(initial = emptyList())

    val quickCommands = listOf(
        stringResource(R.string.quick_cmd_torch),
        stringResource(R.string.quick_cmd_time),
        stringResource(R.string.quick_cmd_alarm),
        stringResource(R.string.quick_cmd_weather)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = stringResource(R.string.home_greeting),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stringResource(R.string.home_subgreeting),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF94A3B8)
                )
            }

            // Status Badge
            Surface(
                color = when (assistantState) {
                    AssistantState.LISTENING -> CyanPrimary.copy(alpha = 0.2f)
                    AssistantState.THINKING -> PurpleAccent.copy(alpha = 0.2f)
                    AssistantState.SPEAKING -> Color(0xFF10B981).copy(alpha = 0.2f)
                    else -> SurfaceDark
                },
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = when (assistantState) {
                        AssistantState.LISTENING -> stringResource(R.string.home_status_listening)
                        AssistantState.THINKING -> stringResource(R.string.home_status_thinking)
                        AssistantState.SPEAKING -> stringResource(R.string.home_status_speaking)
                        else -> stringResource(R.string.home_status_ready)
                    },
                    color = when (assistantState) {
                        AssistantState.LISTENING -> CyanPrimary
                        AssistantState.THINKING -> PurpleAccent
                        AssistantState.SPEAKING -> Color(0xFF10B981)
                        else -> Color(0xFF94A3B8)
                    },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Center Pulsing Mic
        MicWaveformAnimation(
            state = assistantState,
            onClick = onMicClicked
        )

        Text(
            text = if (assistantState == AssistantState.IDLE) stringResource(R.string.home_tap_to_speak) else stringResource(R.string.home_stop_speaking),
            color = Color(0xFF94A3B8),
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 12.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Active Speech Display
        if (lastUserSpeech.isNotBlank() || lastAssistantSpeech.isNotBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (lastUserSpeech.isNotBlank()) {
                        Text(
                            text = "আপনি: $lastUserSpeech",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }
                    if (lastAssistantSpeech.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "সোনেট: $lastAssistantSpeech",
                            color = CyanPrimary,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Quick Commands Chips
        Text(
            text = stringResource(R.string.home_quick_actions),
            color = Color(0xFF64748B),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(bottom = 8.dp)
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(quickCommands) { cmd ->
                Surface(
                    color = SurfaceDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { onQuickCommand(cmd) }
                ) {
                    Text(
                        text = cmd,
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Recent Conversation
        Text(
            text = stringResource(R.string.last_conversation),
            color = Color(0xFF64748B),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(bottom = 8.dp)
        )

        if (recentConversations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.no_recent_conversation),
                    color = Color(0xFF64748B),
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(recentConversations.take(6)) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (item.role == "USER") "ব্যবহারকারী" else "সোনেট",
                                color = if (item.role == "USER") Color(0xFF94A3B8) else CyanPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.text,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
