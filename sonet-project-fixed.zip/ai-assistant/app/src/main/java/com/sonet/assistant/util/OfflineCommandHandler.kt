package com.sonet.assistant.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OfflineCommandHandler {

    data class OfflineResult(
        val handled: Boolean,
        val responseSpeech: String,
        val userPrompt: String = ""
    )

    fun tryHandleOffline(context: Context, rawText: String): OfflineResult {
        val text = rawText.trim().lowercase(Locale.ROOT)

        // 1. Flashlight / Torch
        if (containsAny(text, listOf("টর্চ জ্বালাও", "টর্চ অন", "টর্চ অন করো", "torch on", "flashlight on", "turn on flashlight"))) {
            setTorch(context, true)
            return OfflineResult(true, "টর্চ জ্বালানো হয়েছে।")
        }
        if (containsAny(text, listOf("টর্চ বন্ধ", "টর্চ নিভাও", "টর্চ অফ", "torch off", "flashlight off", "turn off flashlight"))) {
            setTorch(context, false)
            return OfflineResult(true, "টর্চ বন্ধ করা হয়েছে।")
        }

        // 2. Battery level
        if (containsAny(text, listOf("ব্যাটারি কত", "ব্যাটারি লেভেল", "battery", "battery percentage", "battery level"))) {
            val level = getBatteryLevel(context)
            return OfflineResult(true, "আপনার ফোনে বর্তমানে $level% ব্যাটারি চার্জ আছে।")
        }

        // 3. Current time / Date
        if (containsAny(text, listOf("কয়টা বাজে", "সময় কত", "time", "what time is it", "current time"))) {
            val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return OfflineResult(true, "এখন সময় $time।")
        }
        if (containsAny(text, listOf("আজকে কি বার", "আজকে কত তারিখ", "আজকের তারিখ", "what is the date", "today's date"))) {
            val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            return OfflineResult(true, "আজ $date।")
        }

        // 4. Quick Settings toggles (open settings pages)
        if (containsAny(text, listOf("ওয়াইফাই", "ওয়াই-ফাই", "wifi", "wi-fi"))) {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return OfflineResult(true, "ওয়াইফাই সেটিংস খোলা হয়েছে।")
        }
        if (containsAny(text, listOf("ব্লুটুথ", "bluetooth"))) {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return OfflineResult(true, "ব্লুটুথ সেটিংস খোলা হয়েছে।")
        }

        // 5. Volume controls
        if (containsAny(text, listOf("ভলিউম বাড়াও", "সাউন্ড বাড়াও", "volume up", "increase volume"))) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            audioManager?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            return OfflineResult(true, "ভলিউম বাড়ানো হয়েছে।")
        }
        if (containsAny(text, listOf("ভলিউম কমাও", "সাউন্ড কমাও", "volume down", "decrease volume"))) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            audioManager?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return OfflineResult(true, "ভলিউম কমানো হয়েছে।")
        }
        if (containsAny(text, listOf("সাইলেন্ট করো", "মিউট করো", "mute", "silent mode"))) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            audioManager?.ringerMode = AudioManager.RINGER_MODE_SILENT
            return OfflineResult(true, "ফোন সাইলেন্ট করা হয়েছে।")
        }

        // 6. Alarms / Timer
        if (containsAny(text, listOf("অ্যালার্ম খোলো", "open alarm", "show alarms"))) {
            val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                return OfflineResult(true, "অ্যালার্ম খোলা হয়েছে।")
            }
        }

        // Not handled offline
        return OfflineResult(false, "")
    }

    private fun containsAny(text: String, keywords: List<String>): Boolean {
        return keywords.any { text.contains(it, ignoreCase = true) }
    }

    private fun setTorch(context: Context, enable: Boolean) {
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return
            cameraManager.setTorchMode(cameraId, enable)
        } catch (_: Exception) {}
    }

    private fun getBatteryLevel(context: Context): Int {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) {
            (level * 100) / scale
        } else {
            50
        }
    }
}
