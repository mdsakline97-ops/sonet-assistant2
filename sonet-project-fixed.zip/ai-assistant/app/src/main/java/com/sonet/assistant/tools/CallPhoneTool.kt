package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.util.PermissionUtils
import org.json.JSONArray
import org.json.JSONObject

class CallPhoneTool(private val context: Context) : Tool {
    override val name: String = "make_phone_call"
    override val description: String = "Place a phone call to a given phone number or contact."
    override val isSensitive: Boolean = true

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("phone_number", JSONObject().apply {
                    put("type", "string")
                    put("description", "The phone number to call (e.g. +8801700000000)")
                })
                put("contact_name", JSONObject().apply {
                    put("type", "string")
                    put("description", "Name of the person being called")
                })
            })
            put("required", JSONArray(listOf("phone_number")))
        }
    }

    override fun getConfirmationMessage(arguments: JSONObject): String {
        val number = arguments.optString("phone_number")
        val name = arguments.optString("contact_name", number)
        return "আপনি কি $name ($number) নম্বরে কল করতে চান?"
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val number = arguments.optString("phone_number", "").trim()
        if (number.isEmpty()) {
            return ToolResult(toolCallId = callId, name = name, resultText = "ফোন নম্বর উল্লেখ করা হয়নি।", isSuccess = false)
        }

        return try {
            val intent = if (PermissionUtils.hasPhone(context)) {
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            } else {
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ToolResult(toolCallId = callId, name = name, resultText = "$number নম্বরে কল করা হচ্ছে।")
        } catch (e: Exception) {
            ToolResult(toolCallId = callId, name = name, resultText = "কল করতে সমস্যা হয়েছে: ${e.message}", isSuccess = false)
        }
    }
}
