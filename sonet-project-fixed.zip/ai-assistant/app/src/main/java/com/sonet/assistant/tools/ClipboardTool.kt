package com.sonet.assistant.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.sonet.assistant.data.model.ToolResult
import org.json.JSONArray
import org.json.JSONObject

class ClipboardTool(private val context: Context) : Tool {
    override val name: String = "clipboard"
    override val description: String = "Read text from the clipboard or copy new text to the clipboard."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("read", "copy")))
                    put("description", "Whether to read or copy clipboard text")
                })
                put("text", JSONObject().apply {
                    put("type", "string")
                    put("description", "Text to copy when action is copy")
                })
            })
            put("required", JSONArray(listOf("action")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val action = arguments.optString("action", "read")
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            ?: return ToolResult(callId, name, "ক্লিপবোর্ড সেবা অনুপলব্ধ।", false)

        return if (action == "copy") {
            val textToCopy = arguments.optString("text", "")
            val clip = ClipData.newPlainText("Sonet", textToCopy)
            cm.setPrimaryClip(clip)
            ToolResult(callId, name, "\"$textToCopy\" ক্লিপবোর্ডে কপি করা হয়েছে।")
        } else {
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0).text?.toString() ?: ""
                ToolResult(callId, name, "ক্লিপবোর্ডের লেখা: $text")
            } else {
                ToolResult(callId, name, "ক্লিপবোর্ড বর্তমানে খালি।")
            }
        }
    }
}
