package com.sonet.assistant.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.sonet.assistant.data.model.AssistantState
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.ErrorRed
import com.sonet.assistant.ui.theme.PurpleAccent

@Composable
fun MicWaveformAnimation(
    state: AssistantState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")

    val pulse1 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state == AssistantState.LISTENING) 1.35f else if (state == AssistantState.THINKING) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse1"
    )

    val pulse2 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state == AssistantState.LISTENING) 1.6f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse2"
    )

    val isListeningOrSpeaking = state == AssistantState.LISTENING || state == AssistantState.SPEAKING

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier.size(160.dp)
    ) {
        // Outer glowing ripple 2
        if (state == AssistantState.LISTENING) {
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .scale(pulse2)
                    .clip(CircleShape)
                    .background(CyanPrimary.copy(alpha = 0.15f))
            )
        }

        // Inner glowing ripple 1
        if (state == AssistantState.LISTENING || state == AssistantState.THINKING) {
            Box(
                modifier = Modifier
                    .size(115.dp)
                    .scale(pulse1)
                    .clip(CircleShape)
                    .background(PurpleAccent.copy(alpha = 0.25f))
            )
        }

        // Center mic button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = if (isListeningOrSpeaking) listOf(CyanPrimary, PurpleAccent) else listOf(PurpleAccent, CyanPrimary)
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
        ) {
            Icon(
                imageVector = if (isListeningOrSpeaking) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = "Microphone",
                tint = if (isListeningOrSpeaking) ErrorRed else DarkBackground,
                modifier = Modifier.size(44.dp)
            )
        }
    }
}
