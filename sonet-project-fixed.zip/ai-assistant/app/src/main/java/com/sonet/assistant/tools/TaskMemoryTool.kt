package com.sonet.assistant.tools

import com.sonet.assistant.data.db.entity.NoteEntity
import com.sonet.assistant.data.db.entity.TaskEntity
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.data.repository.TaskRepository
import org.json.JSONArray
import org.json.JSONObject

class TaskMemoryTool(private val taskRepository: TaskRepository) : Tool {
    override val name: String = "task_and_memory"
    override val description: String = "Save a task/reminder, save a user preference/fact to memory, or write a note."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("category", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("create_task", "save_memory", "save_note")))
                    put("description", "Type of storage: create_task, save_memory, or save_note")
                })
                put("title_or_key", JSONObject().apply {
                    put("type", "string")
                    put("description", "Title of the task/note or key for memory")
                })
                put("content_or_value", JSONObject().apply {
                    put("type", "string")
                    put("description", "Content/description or value")
                })
                put("delay_minutes", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Minutes in the future for scheduled task/reminder")
                })
            })
            put("required", JSONArray(listOf("category", "title_or_key")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val category = arguments.optString("category", "save_memory")
        val titleOrKey = arguments.optString("title_or_key", "").trim()
        val contentOrValue = arguments.optString("content_or_value", "").trim()

        return when (category) {
            "create_task" -> {
                val delayMinutes = arguments.optInt("delay_minutes", 0)
                val scheduleTime = if (delayMinutes > 0) System.currentTimeMillis() + (delayMinutes * 60 * 1000L) else 0L
                val task = TaskEntity(
                    title = titleOrKey,
                    description = contentOrValue,
                    triggerType = if (scheduleTime > 0) "time" else "on_command",
                    scheduleTimeMillis = scheduleTime,
                    status = "ACTIVE"
                )
                val id = taskRepository.saveTask(task)
                val reminderNote = if (delayMinutes > 0) " ($delayMinutes মিনিট পর মনে করিয়ে দেওয়া হবে)" else ""
                ToolResult(callId, name, "টাস্ক #$id তৈরি হয়েছে: \"$titleOrKey\"$reminderNote।")
            }
            "save_note" -> {
                val note = NoteEntity(title = titleOrKey, content = contentOrValue)
                taskRepository.saveNote(note)
                ToolResult(callId, name, "নোট সংরক্ষণ করা হয়েছে: \"$titleOrKey\"।")
            }
            "save_memory" -> {
                taskRepository.saveMemory(key = titleOrKey, value = contentOrValue)
                ToolResult(callId, name, "মনে রাখা হলো: $titleOrKey = $contentOrValue।")
            }
            else -> ToolResult(callId, name, "অজানা ক্যাটাগরি: $category", false)
        }
    }
}
