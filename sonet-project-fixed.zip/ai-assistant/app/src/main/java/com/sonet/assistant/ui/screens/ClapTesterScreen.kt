package com.sonet.assistant.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.SuccessGreen
import com.sonet.assistant.ui.theme.SurfaceDark
import com.sonet.assistant.voice.ClapDetector
import kotlinx.coroutines.delay

@Composable
fun ClapTesterScreen(
    prefsRepo: PreferencesRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var sensitivity by remember { mutableFloatStateOf(prefsRepo.getClapSensitivity()) }
    var currentAmplitude by remember { mutableFloatStateOf(0f) }
    var clapDetectedFlash by remember { mutableStateOf(false) }
    var doubleClapCount by remember { mutableIntStateOf(0) }

    val circleColor by animateColorAsState(
        targetValue = if (clapDetectedFlash) SuccessGreen else CyanPrimary.copy(alpha = 0.2f),
        label = "clapColor"
    )

    val detector = remember {
        ClapDetector(context) {
            doubleClapCount++
        }.apply {
            this.sensitivity = sensitivity
            this.testListener = object : ClapDetector.ClapTestListener {
                override fun onAmplitudeUpdate(normalizedAmplitude: Float) {
                    currentAmplitude = normalizedAmplitude
                }

                override fun onSingleClapDetected() {
                    clapDetectedFlash = true
                }
            }
        }
    }

    LaunchedEffect(clapDetectedFlash) {
        if (clapDetectedFlash) {
            delay(350)
            clapDetectedFlash = false
        }
    }

    DisposableEffect(Unit) {
        detector.start()
        onDispose {
            detector.stop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "তালি শনাক্তকরণ পরীক্ষা",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "মাইক্রোফোনের সামনে দুইবার তালি দিন এবং দেখুন শনাক্ত হয় কিনা",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF94A3B8),
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Clap indicator circle
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(circleColor)
            ) {
                Icon(
                    imageVector = Icons.Default.WavingHand,
                    contentDescription = null,
                    tint = if (clapDetectedFlash) DarkBackground else CyanPrimary,
                    modifier = Modifier.size(64.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (clapDetectedFlash) "👏 তালি শনাক্ত হয়েছে!" else "তালি শুনছি…",
                color = if (clapDetectedFlash) SuccessGreen else Color(0xFF94A3B8),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (doubleClapCount > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "দ্বৈত তালি জেগে ওঠার সংখ্যা: $doubleClapCount বার 🎉",
                    color = CyanPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Real-time amplitude meter
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "মাইক্রোফোন লেভেল (ভলিউম)",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { currentAmplitude },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = if (currentAmplitude > 0.6f) SuccessGreen else CyanPrimary,
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "সংবেদনশীলতা (Sensitivity): ${(sensitivity * 100).toInt()}%",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "বেশি রাখলে মৃদু তালিতেও সাড়া দেবে, কম রাখলে শুধু জোরালো তালি নেবে",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Slider(
                        value = sensitivity,
                        onValueChange = {
                            sensitivity = it
                            detector.sensitivity = it
                            prefsRepo.setClapSensitivity(it)
                        },
                        valueRange = 0.1f..1.0f
                    )
                }
            }
        }

        Button(
            onClick = onBack,
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(text = "সম্পন্ন (Done)", color = DarkBackground, fontWeight = FontWeight.Bold)
        }
    }
}
