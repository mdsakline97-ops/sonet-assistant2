package com.sonet.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val serviceIntent = Intent(context, SonetForegroundService::class.java).apply {
                this.action = SonetForegroundService.ACTION_START_SERVICE
            }
            try {
                context.startForegroundService(serviceIntent)
            } catch (_: Exception) {}
        }
    }
}
