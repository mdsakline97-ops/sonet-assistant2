package com.sonet.assistant.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sonet.assistant.R
import com.sonet.assistant.data.db.SonetDatabase

class TaskWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val taskId = inputData.getLong("TASK_ID", -1L)
        val title = inputData.getString("TASK_TITLE") ?: "সোনেট রিমাইন্ডার"
        val desc = inputData.getString("TASK_DESC") ?: ""

        // Post notification
        postNotification(title, desc)

        // Update task status in database
        if (taskId != -1L) {
            val db = SonetDatabase.getInstance(context)
            val task = db.taskDao().getTaskById(taskId)
            if (task != null) {
                db.taskDao().updateTask(
                    task.copy(
                        status = "COMPLETED",
                        lastRun = System.currentTimeMillis(),
                        result = "টাস্ক সম্পন্ন হয়েছে"
                    )
                )
            }
        }

        // Notify active service if running
        SonetForegroundService.instance?.speakNotification("রিমাইন্ডার: $title")

        return Result.success()
    }

    private fun postNotification(title: String, desc: String) {
        val channelId = "sonet_tasks_channel"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "সোনেট নির্ধারিত কাজ",
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("সোনেট কাজ: $title")
            .setContentText(desc.ifEmpty { "আপনার নির্ধারিত কাজের সময় হয়েছে।" })
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        nm.notify((System.currentTimeMillis() % 10000).toInt(), notification)
    }
}
