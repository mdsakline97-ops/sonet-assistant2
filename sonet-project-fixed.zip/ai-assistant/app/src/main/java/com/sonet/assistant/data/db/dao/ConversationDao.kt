package com.sonet.assistant.data.db.dao

import androidx.room.*
import com.sonet.assistant.data.db.entity.ConversationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentConversations(limit: Int = 50): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY timestamp ASC")
    suspend fun getAllConversationsSnapshot(): List<ConversationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(item: ConversationEntity): Long

    @Query("DELETE FROM conversations")
    suspend fun clearAll()
}
