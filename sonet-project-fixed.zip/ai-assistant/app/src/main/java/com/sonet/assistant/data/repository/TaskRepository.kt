package com.sonet.assistant.data.repository

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.sonet.assistant.data.db.SonetDatabase
import com.sonet.assistant.data.db.entity.ConversationEntity
import com.sonet.assistant.data.db.entity.MemoryEntity
import com.sonet.assistant.data.db.entity.NoteEntity
import com.sonet.assistant.data.db.entity.TaskEntity
import com.sonet.assistant.service.TaskAlarmReceiver
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val context: Context) {
    private val db = SonetDatabase.getInstance(context)
    private val taskDao = db.taskDao()
    private val noteDao = db.noteDao()
    private val memoryDao = db.memoryDao()
    private val conversationDao = db.conversationDao()
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    // Tasks
    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()
    suspend fun getTaskById(id: Long): TaskEntity? = taskDao.getTaskById(id)

    suspend fun saveTask(task: TaskEntity): Long {
        val id = taskDao.insertTask(task)
        val created = task.copy(id = id)
        if (created.status == "ACTIVE" && created.scheduleTimeMillis > System.currentTimeMillis()) {
            scheduleAlarm(created)
        }
        return id
    }

    suspend fun updateTask(task: TaskEntity) {
        taskDao.updateTask(task)
        if (task.status == "ACTIVE" && task.scheduleTimeMillis > System.currentTimeMillis()) {
            scheduleAlarm(task)
        } else {
            cancelAlarm(task.id)
        }
    }

    suspend fun deleteTask(task: TaskEntity) {
        cancelAlarm(task.id)
        taskDao.deleteTask(task)
    }

    suspend fun deleteTaskById(id: Long) {
        cancelAlarm(id)
        taskDao.deleteTaskById(id)
    }

    private fun scheduleAlarm(task: TaskEntity) {
        alarmManager?.let { am ->
            val intent = Intent(context, TaskAlarmReceiver::class.java).apply {
                putExtra("TASK_ID", task.id)
                putExtra("TASK_TITLE", task.title)
                putExtra("TASK_DESC", task.description)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                task.id.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (am.canScheduleExactAlarms()) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.scheduleTimeMillis, pendingIntent)
                    } else {
                        am.set(AlarmManager.RTC_WAKEUP, task.scheduleTimeMillis, pendingIntent)
                    }
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.scheduleTimeMillis, pendingIntent)
                }
            } catch (_: Exception) {}
        }
    }

    private fun cancelAlarm(taskId: Long) {
        alarmManager?.let { am ->
            val intent = Intent(context, TaskAlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                am.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }

    // Notes
    fun getAllNotes(): Flow<List<NoteEntity>> = noteDao.getAllNotes()
    suspend fun saveNote(note: NoteEntity): Long = noteDao.insertNote(note)
    suspend fun updateNote(note: NoteEntity) = noteDao.updateNote(note)
    suspend fun deleteNote(note: NoteEntity) = noteDao.deleteNote(note)
    suspend fun deleteNoteById(id: Long) = noteDao.deleteNoteById(id)

    // Memories
    fun getAllMemories(): Flow<List<MemoryEntity>> = memoryDao.getAllMemories()
    suspend fun getMemoriesSnapshot(): List<MemoryEntity> = memoryDao.getMemoriesSnapshot()
    suspend fun saveMemory(key: String, value: String, category: String = "preference"): Long {
        return memoryDao.insertMemory(MemoryEntity(key = key, value = value, category = category))
    }
    suspend fun deleteMemoryById(id: Long) = memoryDao.deleteMemoryById(id)

    // Conversations
    fun getRecentConversations(limit: Int = 30): Flow<List<ConversationEntity>> = conversationDao.getRecentConversations(limit)
    suspend fun saveConversation(role: String, text: String, provider: String = "") {
        conversationDao.insertConversation(ConversationEntity(role = role, text = text, providerUsed = provider))
    }
    suspend fun clearConversations() = conversationDao.clearAll()
}
