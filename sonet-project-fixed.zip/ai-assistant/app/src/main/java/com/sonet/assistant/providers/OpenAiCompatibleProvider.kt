package com.sonet.assistant.providers

import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.ChatMessage
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.model.Role
import com.sonet.assistant.data.model.ToolCall
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class OpenAiCompatibleProvider : AiProvider {
    override val type: ProviderType = ProviderType.OPENAI_COMPATIBLE

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun chat(
        config: AiProviderConfig,
        systemPrompt: String,
        messages: List<ChatMessage>,
        toolsJson: Any?
    ): ProviderResponse = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) {
            throw IOException("এপিআই কি (API Key) খালি। অনুগ্রহ করে সেটিংসে কি প্রদান করুন।")
        }

        val baseUrl = config.baseUrl.trimEnd('/')
        val url = if (baseUrl.endsWith("/chat/completions")) baseUrl else "$baseUrl/chat/completions"

        val rootJson = JSONObject().apply {
            put("model", config.modelName.trim().ifEmpty { "llama-3.1-70b-versatile" })
            put("temperature", 0.7)
        }

        val messagesArray = JSONArray()

        // System prompt
        if (systemPrompt.isNotBlank()) {
            messagesArray.put(JSONObject().apply {
                put("role", "system")
                put("content", systemPrompt)
            })
        }

        for (msg in messages) {
            val msgObj = JSONObject()
            when (msg.role) {
                Role.USER -> {
                    msgObj.put("role", "user")
                    msgObj.put("content", msg.content)
                }
                Role.ASSISTANT -> {
                    msgObj.put("role", "assistant")
                    msgObj.put("content", msg.content)
                    if (msg.toolCalls.isNotEmpty()) {
                        val tcArray = JSONArray()
                        for (tc in msg.toolCalls) {
                            tcArray.put(JSONObject().apply {
                                put("id", tc.id)
                                put("type", "function")
                                put("function", JSONObject().apply {
                                    put("name", tc.name)
                                    put("arguments", tc.arguments)
                                })
                            })
                        }
                        msgObj.put("tool_calls", tcArray)
                    }
                }
                Role.SYSTEM -> {
                    msgObj.put("role", "system")
                    msgObj.put("content", msg.content)
                }
                Role.TOOL -> {
                    msgObj.put("role", "tool")
                    msgObj.put("content", msg.content)
                    msgObj.put("tool_call_id", msg.toolCallId ?: "call_0")
                }
            }
            messagesArray.put(msgObj)
        }
        rootJson.put("messages", messagesArray)

        // Tools
        if (toolsJson is JSONArray && toolsJson.length() > 0) {
            rootJson.put("tools", toolsJson)
            rootJson.put("tool_choice", "auto")
        }

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${config.apiKey.trim()}")
            .header("Content-Type", "application/json")
            .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            val errorMsg = parseErrorMessage(response.code, responseBody, config.modelName, baseUrl)
            throw IOException(errorMsg)
        }

        val json = JSONObject(responseBody)
        val choices = json.optJSONArray("choices")
        if (choices == null || choices.length() == 0) {
            return@withContext ProviderResponse(content = "কোনো উত্তর পাওয়া যায়নি।")
        }

        val firstChoice = choices.getJSONObject(0)
        val message = firstChoice.optJSONObject("message")
        val content = message?.optString("content", "") ?: ""
        val toolCallsList = mutableListOf<ToolCall>()

        val rawToolCalls = message?.optJSONArray("tool_calls")
        if (rawToolCalls != null) {
            for (i in 0 until rawToolCalls.length()) {
                val tc = rawToolCalls.getJSONObject(i)
                val id = tc.optString("id", "call_$i")
                val fn = tc.optJSONObject("function")
                if (fn != null) {
                    val name = fn.getString("name")
                    val args = fn.optString("arguments", "{}")
                    toolCallsList.add(ToolCall(id = id, name = name, arguments = args))
                }
            }
        }

        ProviderResponse(
            content = content.trim(),
            toolCalls = toolCallsList,
            rawJson = responseBody
        )
    }

    override suspend fun listModels(config: AiProviderConfig): List<String> = withContext(Dispatchers.IO) {
        val baseUrl = config.baseUrl.trimEnd('/')
        val url = if (baseUrl.endsWith("/chat/completions")) {
            baseUrl.substringBeforeLast("/chat/completions") + "/models"
        } else {
            "$baseUrl/models"
        }

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${config.apiKey.trim()}")
            .get()
            .build()

        val response = httpClient.newCall(request).execute()
        val body = response.body?.string() ?: ""
        if (!response.isSuccessful) {
            throw IOException(parseErrorMessage(response.code, body, "models", baseUrl))
        }

        val json = JSONObject(body)
        val dataArray = json.optJSONArray("data") ?: JSONArray()
        val list = mutableListOf<String>()
        for (i in 0 until dataArray.length()) {
            val item = dataArray.getJSONObject(i)
            val id = item.optString("id")
            if (id.isNotBlank()) list.add(id)
        }
        list
    }

    override suspend fun testConnection(config: AiProviderConfig): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val models = listModels(config)
            if (models.isNotEmpty()) {
                Pair(true, "সংযোগ সফল! মডেল সংখ্যা: ${models.size}")
            } else {
                Pair(true, "সার্ভারের সাথে সফলভাবে সংযোগ স্থাপিত হয়েছে।")
            }
        } catch (e: Exception) {
            Pair(false, e.message ?: "সংযোগ ব্যর্থ")
        }
    }

    private fun parseErrorMessage(code: Int, body: String, model: String, baseUrl: String): String {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message") ?: body
        } catch (_: Exception) {
            body
        }
        return when (code) {
            401 -> "অনুমোদন ব্যর্থ (401): এপিআই কি সঠিক নয়। অনুগ্রহ করে আপনার প্রদানকারীর ড্যাশবোর্ড থেকে সঠিক কি কপি করুন।"
            404 -> "রুট বা মডেল পাওয়া যায়নি (404): \"$model\" বা $baseUrl সঠিক নয়। মডেল তালিকা রিফ্রেশ করে সঠিক মডেল বেছে নিন।"
            429 -> "রেট লিমিট (429): বিনামূল্যে ব্যবহারের অনুরোধের সীমা শেষ হয়েছে। কিছুক্ষণ অপেক্ষা করুন অথবা অন্য প্রোভাইডারে স্যুইচ করুন।"
            500, 502, 503 -> "সার্ভার সমস্যা ($code): এআই প্রদানকারীর সার্ভারে সাময়িক বিভ্রাট চলছে।"
            else -> "ত্রুটি ($code): $detail"
        }
    }
}
