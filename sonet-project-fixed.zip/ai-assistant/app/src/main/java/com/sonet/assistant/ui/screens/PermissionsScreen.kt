package com.sonet.assistant.ui.screens

import android.app.Activity
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonet.assistant.R
import com.sonet.assistant.util.PermissionUtils
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.SuccessGreen
import com.sonet.assistant.ui.theme.SurfaceDark

data class PermCheckItem(
    val id: String,
    val title: String,
    val desc: String,
    val isGranted: Boolean,
    val onFix: () -> Unit
)

@Composable
fun PermissionsScreen(
    onAllFinished: () -> Unit
) {
    val context = LocalContext.current
    var refreshTrigger by remember { mutableStateOf(0) }

    val runtimeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshTrigger++
    }

    val items = remember(refreshTrigger) {
        listOf(
            PermCheckItem(
                id = "mic",
                title = context.getString(R.string.perm_mic_title),
                desc = context.getString(R.string.perm_mic_desc),
                isGranted = PermissionUtils.hasRecordAudio(context),
                onFix = { runtimeLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO)) }
            ),
            PermCheckItem(
                id = "overlay",
                title = context.getString(R.string.perm_overlay_title),
                desc = context.getString(R.string.perm_overlay_desc),
                isGranted = PermissionUtils.hasOverlay(context),
                onFix = { context.startActivity(PermissionUtils.getOverlayIntent(context)) }
            ),
            PermCheckItem(
                id = "battery",
                title = context.getString(R.string.perm_battery_title),
                desc = context.getString(R.string.perm_battery_desc),
                isGranted = PermissionUtils.hasBatteryExemption(context),
                onFix = { context.startActivity(PermissionUtils.getBatteryOptimizationIntent(context)) }
            ),
            PermCheckItem(
                id = "contacts",
                title = context.getString(R.string.perm_contacts_title),
                desc = context.getString(R.string.perm_contacts_desc),
                isGranted = PermissionUtils.hasContacts(context),
                onFix = { runtimeLauncher.launch(arrayOf(android.Manifest.permission.READ_CONTACTS, android.Manifest.permission.WRITE_CONTACTS)) }
            ),
            PermCheckItem(
                id = "phone",
                title = context.getString(R.string.perm_phone_title),
                desc = context.getString(R.string.perm_phone_desc),
                isGranted = PermissionUtils.hasPhone(context),
                onFix = { runtimeLauncher.launch(arrayOf(android.Manifest.permission.CALL_PHONE, android.Manifest.permission.READ_PHONE_STATE)) }
            ),
            PermCheckItem(
                id = "sms",
                title = context.getString(R.string.perm_sms_title),
                desc = context.getString(R.string.perm_sms_desc),
                isGranted = PermissionUtils.hasSms(context),
                onFix = { runtimeLauncher.launch(arrayOf(android.Manifest.permission.SEND_SMS, android.Manifest.permission.READ_SMS)) }
            ),
            PermCheckItem(
                id = "location",
                title = context.getString(R.string.perm_location_title),
                desc = context.getString(R.string.perm_location_desc),
                isGranted = PermissionUtils.hasLocation(context),
                onFix = { runtimeLauncher.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) }
            ),
            PermCheckItem(
                id = "notif_listener",
                title = context.getString(R.string.perm_notification_title),
                desc = context.getString(R.string.perm_notification_desc),
                isGranted = PermissionUtils.hasNotificationListener(context),
                onFix = { context.startActivity(PermissionUtils.getNotificationListenerIntent()) }
            ),
            PermCheckItem(
                id = "accessibility",
                title = context.getString(R.string.perm_accessibility_title),
                desc = context.getString(R.string.perm_accessibility_desc),
                isGranted = PermissionUtils.hasAccessibilityService(context),
                onFix = { context.startActivity(PermissionUtils.getAccessibilityIntent()) }
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(20.dp)
    ) {
        Text(
            text = stringResource(R.string.permission_status_title),
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "সোনেট ঠিকমতো কাজ করার জন্য প্রতিটি অনুমতির পাশে বোতাম চাপুন",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items) { item ->
                PermissionCard(item)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onAllFinished,
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {
            Text(
                text = stringResource(R.string.btn_finish),
                color = DarkBackground,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun PermissionCard(item: PermCheckItem) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.isGranted) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
                    } else {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = item.desc, color = Color(0xFF94A3B8), fontSize = 12.sp)
            }

            if (item.isGranted) {
                Text(
                    text = stringResource(R.string.btn_granted),
                    color = SuccessGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            } else {
                Button(
                    onClick = item.onFix,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.btn_grant),
                        color = DarkBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
