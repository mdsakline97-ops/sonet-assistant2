package com.sonet.assistant.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SonetAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    companion object {
        @Volatile
        var instance: SonetAccessibilityService? = null

        fun isRunning(): Boolean = instance != null

        fun performGlobalBack(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        }

        fun performGlobalHome(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        }

        fun scroll(forward: Boolean): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            return findScrollableAndPerform(root, action)
        }

        private fun findScrollableAndPerform(node: AccessibilityNodeInfo, action: Int): Boolean {
            if (node.isScrollable && node.performAction(action)) {
                return true
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                if (findScrollableAndPerform(child, action)) return true
            }
            return false
        }

        fun typeText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        fun readScreenText(): String {
            val root = instance?.rootInActiveWindow ?: return ""
            val sb = StringBuilder()
            collectText(root, sb)
            return sb.toString().trim()
        }

        private fun collectText(node: AccessibilityNodeInfo, sb: StringBuilder) {
            val txt = node.text?.toString() ?: node.contentDescription?.toString()
            if (!txt.isNullOrBlank()) {
                sb.append(txt).append("\n")
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectText(child, sb)
            }
        }
    }
}
