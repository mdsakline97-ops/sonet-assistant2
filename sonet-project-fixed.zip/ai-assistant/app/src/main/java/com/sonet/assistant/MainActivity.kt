package com.sonet.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sonet.assistant.data.db.entity.TaskEntity
import com.sonet.assistant.data.repository.CrashLogManager
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.data.repository.TaskRepository
import com.sonet.assistant.service.SonetForegroundService
import com.sonet.assistant.ui.navigation.Screen
import com.sonet.assistant.ui.screens.*
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.SonetTheme
import com.sonet.assistant.ui.theme.SurfaceDark
import com.sonet.assistant.util.LanguageManager
import kotlinx.coroutines.launch

data class BottomNavItem(
    val screen: Screen,
    val titleRes: Int,
    val icon: ImageVector
)

class MainActivity : ComponentActivity() {

    private lateinit var prefsRepo: PreferencesRepository
    private lateinit var taskRepo: TaskRepository
    private lateinit var crashLogger: CrashLogManager

    override fun attachBaseContext(newBase: Context) {
        val repo = PreferencesRepository(newBase)
        val localized = LanguageManager.setAppLocale(newBase, repo.getLanguage())
        super.attachBaseContext(localized)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefsRepo = PreferencesRepository(this)
        taskRepo = TaskRepository(this)
        crashLogger = CrashLogManager(this)

        val startDest = if (prefsRepo.isOnboarded()) Screen.Home.route else Screen.Onboarding.route

        setContent {
            SonetTheme {
                val navController = rememberNavController()
                val coroutineScope = rememberCoroutineScope()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val bottomNavItems = listOf(
                    BottomNavItem(Screen.Home, R.string.nav_home, Icons.Default.Home),
                    BottomNavItem(Screen.Tasks, R.string.nav_tasks, Icons.Default.CheckCircle),
                    BottomNavItem(Screen.MemoryNotes, R.string.nav_memory, Icons.Default.Note),
                    BottomNavItem(Screen.Settings, R.string.nav_settings, Icons.Default.Settings),
                    BottomNavItem(Screen.Diagnostics, R.string.nav_diagnostics, Icons.Default.BugReport)
                )

                val showBottomNav = currentRoute in bottomNavItems.map { it.screen.route }

                Scaffold(
                    containerColor = DarkBackground,
                    bottomBar = {
                        if (showBottomNav) {
                            NavigationBar(
                                containerColor = SurfaceDark,
                                contentColor = CyanPrimary,
                                tonalElevation = 8.dp
                            ) {
                                bottomNavItems.forEach { item ->
                                    val isSelected = currentRoute == item.screen.route
                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = {
                                            navController.navigate(item.screen.route) {
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = {
                                            Icon(
                                                item.icon,
                                                contentDescription = null,
                                                tint = if (isSelected) CyanPrimary else Color(0xFF94A3B8)
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = stringResource(item.titleRes),
                                                color = if (isSelected) CyanPrimary else Color(0xFF94A3B8)
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = CyanPrimary.copy(alpha = 0.15f)
                                        )
                                    )
                                }
                            }
                        }
                    }
                ) { paddingValues ->
                    NavHost(
                        navController = navController,
                        startDestination = startDest,
                        modifier = Modifier.padding(paddingValues)
                    ) {
                        composable(Screen.Onboarding.route) {
                            OnboardingScreen(
                                onStartPermissions = {
                                    navController.navigate(Screen.Permissions.route)
                                }
                            )
                        }

                        composable(Screen.Permissions.route) {
                            PermissionsScreen(
                                onAllFinished = {
                                    prefsRepo.setOnboarded(true)
                                    startService()
                                    navController.navigate(Screen.Home.route) {
                                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(Screen.Home.route) {
                            HomeScreen(
                                recentConversationsFlow = taskRepo.getRecentConversations(20),
                                onMicClicked = {
                                    startService(SonetForegroundService.ACTION_TRIGGER_LISTEN)
                                },
                                onQuickCommand = { cmd ->
                                    startService(SonetForegroundService.ACTION_TRIGGER_LISTEN)
                                }
                            )
                        }

                        composable(Screen.Tasks.route) {
                            TasksScreen(
                                tasksFlow = taskRepo.getAllTasks(),
                                onAddTask = { title, desc, delayMinutes ->
                                    coroutineScope.launch {
                                        val scheduleTime = if (delayMinutes > 0) System.currentTimeMillis() + (delayMinutes * 60 * 1000L) else 0L
                                        val task = TaskEntity(
                                            title = title,
                                            description = desc,
                                            scheduleTimeMillis = scheduleTime,
                                            triggerType = if (scheduleTime > 0) "time" else "on_command"
                                        )
                                        taskRepo.saveTask(task)
                                    }
                                },
                                onDeleteTask = { task ->
                                    coroutineScope.launch { taskRepo.deleteTask(task) }
                                },
                                onToggleTaskStatus = { task ->
                                    coroutineScope.launch {
                                        val newStatus = if (task.status == "ACTIVE") "PAUSED" else "ACTIVE"
                                        taskRepo.updateTask(task.copy(status = newStatus))
                                    }
                                },
                                onRunTaskNow = { task ->
                                    SonetForegroundService.instance?.speakNotification("টাস্ক চলছে: ${task.title}")
                                }
                            )
                        }

                        composable(Screen.MemoryNotes.route) {
                            MemoryNotesScreen(
                                memoriesFlow = taskRepo.getAllMemories(),
                                notesFlow = taskRepo.getAllNotes(),
                                onAddMemory = { key, value ->
                                    coroutineScope.launch { taskRepo.saveMemory(key, value) }
                                },
                                onDeleteMemory = { id ->
                                    coroutineScope.launch { taskRepo.deleteMemoryById(id) }
                                },
                                onAddNote = { title, content ->
                                    coroutineScope.launch {
                                        taskRepo.saveNote(com.sonet.assistant.data.db.entity.NoteEntity(title = title, content = content))
                                    }
                                },
                                onDeleteNote = { id ->
                                    coroutineScope.launch { taskRepo.deleteNoteById(id) }
                                }
                            )
                        }

                        composable(Screen.Settings.route) {
                            SettingsScreen(
                                prefsRepo = prefsRepo,
                                onNavigateToProviders = { navController.navigate(Screen.ProviderSettings.route) },
                                onNavigateToClapTester = { navController.navigate(Screen.ClapTester.route) },
                                onNavigateToPermissions = { navController.navigate(Screen.Permissions.route) }
                            )
                        }

                        composable(Screen.ProviderSettings.route) {
                            ProviderSettingsScreen(
                                prefsRepo = prefsRepo,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(Screen.Diagnostics.route) {
                            DiagnosticsScreen(crashLogger = crashLogger)
                        }

                        composable(Screen.ClapTester.route) {
                            ClapTesterScreen(
                                prefsRepo = prefsRepo,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun startService(action: String = SonetForegroundService.ACTION_START_SERVICE) {
        val intent = Intent(this, SonetForegroundService::class.java).apply {
            this.action = action
        }
        try {
            startForegroundService(intent)
        } catch (_: Exception) {}
    }
}
