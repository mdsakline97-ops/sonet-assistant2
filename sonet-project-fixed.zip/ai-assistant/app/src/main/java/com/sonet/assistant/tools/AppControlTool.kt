package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.sonet.assistant.data.model.ToolResult
import org.json.JSONArray
import org.json.JSONObject

class AppControlTool(private val context: Context) : Tool {
    override val name: String = "open_or_list_apps"
    override val description: String = "Open an installed Android app by its name, or list available installed apps."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("open", "list")))
                    put("description", "Whether to open an app or list installed apps")
                })
                put("app_name", JSONObject().apply {
                    put("type", "string")
                    put("description", "Name of the app to open (e.g. YouTube, WhatsApp, Chrome, Calculator)")
                })
            })
            put("required", JSONArray(listOf("action")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val action = arguments.optString("action", "open")
        val appName = arguments.optString("app_name", "").trim()
        val pm = context.packageManager

        if (action == "list") {
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { pm.getApplicationLabel(it).toString() }
                .distinct()
                .take(30)
            return ToolResult(
                toolCallId = callId,
                name = name,
                resultText = "ইনস্টল করা অ্যাপস: " + installed.joinToString(", ")
            )
        }

        if (appName.isEmpty()) {
            return ToolResult(toolCallId = callId, name = name, resultText = "কোন অ্যাপটি খুলতে চান তা জানান।", isSuccess = false)
        }

        val launchIntent = findLaunchIntent(appName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ToolResult(toolCallId = callId, name = name, resultText = "$appName অ্যাপটি খোলা হচ্ছে।", isSuccess = true)
        } else {
            ToolResult(toolCallId = callId, name = name, resultText = "\"$appName\" নামের কোনো অ্যাপ খুঁজে পাওয়া যায়নি।", isSuccess = false)
        }
    }

    private fun findLaunchIntent(query: String): Intent? {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        // 1. Direct label match
        for (app in apps) {
            val label = pm.getApplicationLabel(app).toString()
            if (label.equals(query, ignoreCase = true) || label.contains(query, ignoreCase = true)) {
                val intent = pm.getLaunchIntentForPackage(app.packageName)
                if (intent != null) return intent
            }
        }
        // 2. Common package name mapping
        val common = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "facebook" to "com.facebook.katana",
            "camera" to "camera",
            "calculator" to "calculator"
        )
        for ((key, pkg) in common) {
            if (query.contains(key, ignoreCase = true)) {
                val intent = pm.getLaunchIntentForPackage(pkg)
                if (intent != null) return intent
            }
        }
        return null
    }
}
