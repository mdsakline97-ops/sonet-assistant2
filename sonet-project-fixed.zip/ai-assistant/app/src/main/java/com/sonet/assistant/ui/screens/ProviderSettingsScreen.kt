package com.sonet.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.providers.GeminiProvider
import com.sonet.assistant.providers.OpenAiCompatibleProvider
import com.sonet.assistant.providers.ClaudeProvider
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.ErrorRed
import com.sonet.assistant.ui.theme.SuccessGreen
import com.sonet.assistant.ui.theme.SurfaceDark
import kotlinx.coroutines.launch

@Composable
fun ProviderSettingsScreen(
    prefsRepo: PreferencesRepository,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedProviderType by remember { mutableStateOf(prefsRepo.getPrimaryProvider()) }
    val configs = remember { mutableStateMapOf<ProviderType, AiProviderConfig>() }

    LaunchedEffect(Unit) {
        prefsRepo.getProviderConfigs().forEach {
            configs[it.type] = it
        }
    }

    val currentConfig = configs[selectedProviderType] ?: AiProviderConfig(
        type = selectedProviderType,
        apiKey = "",
        baseUrl = selectedProviderType.defaultBaseUrl,
        modelName = selectedProviderType.defaultModel
    )

    var apiKey by remember(selectedProviderType) { mutableStateOf(currentConfig.apiKey) }
    var baseUrl by remember(selectedProviderType) { mutableStateOf(currentConfig.baseUrl) }
    var modelName by remember(selectedProviderType) { mutableStateOf(currentConfig.modelName) }
    var showApiKey by remember { mutableStateOf(false) }

    var testStatusText by remember { mutableStateOf("") }
    var isTesting by remember { mutableStateOf(false) }
    var isTestSuccess by remember { mutableStateOf<Boolean?>(null) }

    var availableModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var showModelPicker by remember { mutableStateOf(false) }
    var isFetchingModels by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "এআই ইঞ্জিন ও এপিআই কি",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "বিনামূল্যে Gemini বা Groq এপিআই কি যুক্ত করে সোনেটকে সুপারচার্জ করুন",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        // Select Provider
        Text(text = "প্রধান এআই প্রোভাইডার নির্বাচন", color = CyanPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProviderType.entries.forEach { type ->
                FilterChip(
                    selected = selectedProviderType == type,
                    onClick = {
                        // Save current before switching
                        configs[selectedProviderType] = currentConfig.copy(
                            apiKey = apiKey,
                            baseUrl = baseUrl,
                            modelName = modelName
                        )
                        selectedProviderType = type
                        testStatusText = ""
                        isTestSuccess = null
                    },
                    label = { Text(when (type) {
                        ProviderType.GEMINI -> "Gemini"
                        ProviderType.OPENAI_COMPATIBLE -> "Groq / OpenAI"
                        ProviderType.CLAUDE -> "Claude"
                    }) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "${selectedProviderType.displayName} সেটিংস",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // API Key field
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("এপিআই কি (API Key)") },
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Base URL
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    label = { Text("বেস ইউআরএল (Base URL)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Model Name
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = modelName,
                        onValueChange = { modelName = it },
                        label = { Text("মডেলের নাম (Model Name)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            isFetchingModels = true
                            coroutineScope.launch {
                                try {
                                    val tempConfig = currentConfig.copy(apiKey = apiKey, baseUrl = baseUrl, modelName = modelName)
                                    val provider = when (selectedProviderType) {
                                        ProviderType.GEMINI -> GeminiProvider()
                                        ProviderType.OPENAI_COMPATIBLE -> OpenAiCompatibleProvider()
                                        ProviderType.CLAUDE -> ClaudeProvider()
                                    }
                                    val list = provider.listModels(tempConfig)
                                    if (list.isNotEmpty()) {
                                        availableModels = list
                                        showModelPicker = true
                                    } else {
                                        testStatusText = "কোনো মডেল তালিকা পাওয়া যায়নি।"
                                    }
                                } catch (e: Exception) {
                                    testStatusText = "মডেল তালিকা আনতে ব্যর্থ: ${e.message}"
                                } finally {
                                    isFetchingModels = false
                                }
                            }
                        },
                        modifier = Modifier
                            .background(CyanPrimary.copy(alpha = 0.15f), shape = RoundedCornerShape(12.dp))
                            .padding(4.dp)
                    ) {
                        if (isFetchingModels) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = CyanPrimary)
                        } else {
                            Icon(Icons.Default.List, contentDescription = "Fetch Models", tint = CyanPrimary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Test Connection Button
                Button(
                    onClick = {
                        isTesting = true
                        testStatusText = "পরীক্ষা করা হচ্ছে…"
                        isTestSuccess = null
                        coroutineScope.launch {
                            try {
                                val tempConfig = currentConfig.copy(apiKey = apiKey, baseUrl = baseUrl, modelName = modelName)
                                val provider = when (selectedProviderType) {
                                    ProviderType.GEMINI -> GeminiProvider()
                                    ProviderType.OPENAI_COMPATIBLE -> OpenAiCompatibleProvider()
                                    ProviderType.CLAUDE -> ClaudeProvider()
                                }
                                val result = provider.testConnection(tempConfig)
                                isTestSuccess = result.first
                                testStatusText = result.second
                            } catch (e: Exception) {
                                isTestSuccess = false
                                testStatusText = "ব্যর্থ: ${e.message}"
                            } finally {
                                isTesting = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyanPrimary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(text = "সংযোগ পরীক্ষা করুন (Test Connection)", color = CyanPrimary)
                }

                if (testStatusText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = testStatusText,
                        color = if (isTestSuccess == true) SuccessGreen else if (isTestSuccess == false) ErrorRed else Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Save Button
        Button(
            onClick = {
                val updated = currentConfig.copy(
                    type = selectedProviderType,
                    apiKey = apiKey.trim(),
                    baseUrl = baseUrl.trim(),
                    modelName = modelName.trim()
                )
                configs[selectedProviderType] = updated
                prefsRepo.updateProviderConfig(updated)
                prefsRepo.setPrimaryProvider(selectedProviderType)
                onBack()
            },
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = DarkBackground)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "সংরক্ষণ করুন (Save & Set Primary)", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }

    if (showModelPicker) {
        AlertDialog(
            onDismissRequest = { showModelPicker = false },
            containerColor = SurfaceDark,
            title = { Text("মডেল নির্বাচন করুন", color = Color.White) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                    availableModels.forEach { m ->
                        Text(
                            text = m,
                            color = if (m == modelName) CyanPrimary else Color.White,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    modelName = m
                                    showModelPicker = false
                                }
                                .padding(vertical = 10.dp)
                        )
                        Divider(color = Color(0xFF1E293B))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showModelPicker = false }) {
                    Text("বন্ধ করুন", color = CyanPrimary)
                }
            }
        )
    }
}
