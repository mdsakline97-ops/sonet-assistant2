package com.sonet.assistant.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.sonet.assistant.data.db.dao.ConversationDao
import com.sonet.assistant.data.db.dao.MemoryDao
import com.sonet.assistant.data.db.dao.NoteDao
import com.sonet.assistant.data.db.dao.TaskDao
import com.sonet.assistant.data.db.entity.ConversationEntity
import com.sonet.assistant.data.db.entity.MemoryEntity
import com.sonet.assistant.data.db.entity.NoteEntity
import com.sonet.assistant.data.db.entity.TaskEntity

@Database(
    entities = [
        TaskEntity::class,
        NoteEntity::class,
        MemoryEntity::class,
        ConversationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SonetDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun noteDao(): NoteDao
    abstract fun memoryDao(): MemoryDao
    abstract fun conversationDao(): ConversationDao

    companion object {
        @Volatile
        private var INSTANCE: SonetDatabase? = null

        fun getInstance(context: Context): SonetDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SonetDatabase::class.java,
                    "sonet_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
