package com.sonet.assistant.tools

import com.sonet.assistant.data.model.ToolCall
import com.sonet.assistant.data.model.ToolResult
import org.json.JSONObject

class ToolDispatcher(private val registry: ToolRegistry) {

    suspend fun execute(toolCall: ToolCall, userConfirmed: Boolean = false): ToolResult {
        val tool = registry.getTool(toolCall.name)
            ?: return ToolResult(
                toolCallId = toolCall.id,
                name = toolCall.name,
                resultText = "টুল \"${toolCall.name}\" খুঁজে পাওয়া যায়নি।",
                isSuccess = false
            )

        val args = try {
            JSONObject(toolCall.arguments)
        } catch (_: Exception) {
            JSONObject()
        }

        // If tool is sensitive and not yet confirmed by user, request confirmation
        if (tool.isSensitive && !userConfirmed) {
            return ToolResult(
                toolCallId = toolCall.id,
                name = toolCall.name,
                resultText = "নিশ্চিতকরণ আবশ্যক।",
                isSuccess = true,
                requiresConfirmation = true,
                confirmationPrompt = tool.getConfirmationMessage(args)
            )
        }

        return try {
            tool.execute(toolCall.id, args)
        } catch (e: Exception) {
            ToolResult(
                toolCallId = toolCall.id,
                name = toolCall.name,
                resultText = "টুল চালাতে সমস্যা হয়েছে: ${e.message}",
                isSuccess = false
            )
        }
    }

    /**
     * Parse fallback JSON action from plain model text:
     * e.g. {"action": "open_or_list_apps", "parameters": {"action": "open", "app_name": "YouTube"}}
     */
    fun parseFallbackAction(text: String): ToolCall? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start != -1 && end != -1 && end > start) {
            val potentialJson = text.substring(start, end + 1)
            try {
                val obj = JSONObject(potentialJson)
                val action = obj.optString("action")
                if (action.isNotEmpty() && registry.getTool(action) != null) {
                    val params = obj.optJSONObject("parameters") ?: JSONObject()
                    return ToolCall(
                        id = "fallback_${System.currentTimeMillis()}",
                        name = action,
                        arguments = params.toString()
                    )
                }
            } catch (_: Exception) {}
        }
        return null
    }
}
