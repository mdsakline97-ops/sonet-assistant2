package com.sonet.assistant.providers

import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.ChatMessage
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.model.Role
import com.sonet.assistant.data.model.ToolCall
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ClaudeProvider : AiProvider {
    override val type: ProviderType = ProviderType.CLAUDE

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun chat(
        config: AiProviderConfig,
        systemPrompt: String,
        messages: List<ChatMessage>,
        toolsJson: Any?
    ): ProviderResponse = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) {
            throw IOException("Anthropic Claude API Key খালি। অনুগ্রহ করে সেটিংসে সঠিক API Key দিন।")
        }

        val baseUrl = config.baseUrl.trimEnd('/')
        val url = "$baseUrl/v1/messages"

        val rootJson = JSONObject().apply {
            put("model", config.modelName.trim().ifEmpty { "claude-3-haiku-20240307" })
            put("max_tokens", 1024)
        }

        if (systemPrompt.isNotBlank()) {
            rootJson.put("system", systemPrompt)
        }

        val messagesArray = JSONArray()
        for (msg in messages) {
            val msgObj = JSONObject()
            val role = if (msg.role == Role.ASSISTANT) "assistant" else "user"
            msgObj.put("role", role)

            val contentArray = JSONArray()
            if (msg.role == Role.TOOL) {
                contentArray.put(JSONObject().apply {
                    put("type", "tool_result")
                    put("tool_use_id", msg.toolCallId ?: "call_0")
                    put("content", msg.content)
                })
            } else if (msg.toolCalls.isNotEmpty()) {
                if (msg.content.isNotBlank()) {
                    contentArray.put(JSONObject().apply {
                        put("type", "text")
                        put("text", msg.content)
                    })
                }
                for (tc in msg.toolCalls) {
                    contentArray.put(JSONObject().apply {
                        put("type", "tool_use")
                        put("id", tc.id)
                        put("name", tc.name)
                        put("input", JSONObject(tc.arguments))
                    })
                }
            } else {
                contentArray.put(JSONObject().apply {
                    put("type", "text")
                    put("text", msg.content)
                })
            }
            msgObj.put("content", contentArray)
            messagesArray.put(msgObj)
        }
        rootJson.put("messages", messagesArray)

        // Tools
        if (toolsJson is JSONArray && toolsJson.length() > 0) {
            rootJson.put("tools", toolsJson)
        }

        val request = Request.Builder()
            .url(url)
            .header("x-api-key", config.apiKey.trim())
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            val detail = try {
                JSONObject(responseBody).optJSONObject("error")?.optString("message") ?: responseBody
            } catch (_: Exception) {
                responseBody
            }
            val errorMsg = when (response.code) {
                401 -> "ক্লড অনুমোদন ব্যর্থ (401): এপিআই কি সঠিক নয়।"
                404 -> "ক্লড মডেল পাওয়া যায়নি (404): ${config.modelName} সঠিক নয়।"
                429 -> "ক্লড রেট লিমিট (429): অনুরোধের সীমা শেষ হয়েছে।"
                else -> "ক্লড ত্রুটি (${response.code}): $detail"
            }
            throw IOException(errorMsg)
        }

        val json = JSONObject(responseBody)
        val contentItems = json.optJSONArray("content")
        val textSb = StringBuilder()
        val toolCallsList = mutableListOf<ToolCall>()

        if (contentItems != null) {
            for (i in 0 until contentItems.length()) {
                val item = contentItems.getJSONObject(i)
                val type = item.optString("type")
                if (type == "text") {
                    textSb.append(item.optString("text"))
                } else if (type == "tool_use") {
                    val id = item.optString("id")
                    val name = item.optString("name")
                    val input = item.optJSONObject("input") ?: JSONObject()
                    toolCallsList.add(ToolCall(id = id, name = name, arguments = input.toString()))
                }
            }
        }

        ProviderResponse(
            content = textSb.toString().trim(),
            toolCalls = toolCallsList,
            rawJson = responseBody
        )
    }

    override suspend fun listModels(config: AiProviderConfig): List<String> = withContext(Dispatchers.IO) {
        listOf(
            "claude-3-haiku-20240307",
            "claude-3-5-haiku-20241022",
            "claude-3-5-sonnet-20241022"
        )
    }

    override suspend fun testConnection(config: AiProviderConfig): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val resp = chat(config, "Reply with 'ok'", listOf(ChatMessage(Role.USER, "ping")), null)
            if (resp.content.isNotBlank()) {
                Pair(true, "ক্লডের সাথে সংযোগ সফল হয়েছে!")
            } else {
                Pair(false, "কোনো উত্তর পাওয়া যায়নি")
            }
        } catch (e: Exception) {
            Pair(false, e.message ?: "সংযোগ ব্যর্থ")
        }
    }
}
