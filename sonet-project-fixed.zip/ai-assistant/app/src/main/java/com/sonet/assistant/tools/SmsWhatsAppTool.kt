package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.util.PermissionUtils
import org.json.JSONArray
import org.json.JSONObject

class SmsWhatsAppTool(private val context: Context) : Tool {
    override val name: String = "send_message"
    override val description: String = "Send an SMS message or a WhatsApp message to a recipient."
    override val isSensitive: Boolean = true

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("platform", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("sms", "whatsapp")))
                    put("description", "Whether to send via SMS or WhatsApp")
                })
                put("recipient", JSONObject().apply {
                    put("type", "string")
                    put("description", "Phone number or contact name")
                })
                put("message", JSONObject().apply {
                    put("type", "string")
                    put("description", "Text message body to send")
                })
            })
            put("required", JSONArray(listOf("platform", "recipient", "message")))
        }
    }

    override fun getConfirmationMessage(arguments: JSONObject): String {
        val platform = arguments.optString("platform", "SMS").uppercase()
        val recipient = arguments.optString("recipient")
        val message = arguments.optString("message")
        return "আপনি কি $recipient কে $platform এ এই বার্তা পাঠাতে চান: \"$message\"?"
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val platform = arguments.optString("platform", "sms").lowercase()
        val recipient = arguments.optString("recipient", "").trim()
        val message = arguments.optString("message", "").trim()

        if (recipient.isEmpty() || message.isEmpty()) {
            return ToolResult(toolCallId = callId, name = name, resultText = "প্রাপক বা বার্তার বিষয়বস্তু খালি।", isSuccess = false)
        }

        return if (platform == "whatsapp") {
            try {
                val cleanNumber = recipient.replace("[^0-9+]".toRegex(), "")
                val uri = if (cleanNumber.isNotEmpty()) {
                    Uri.parse("https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode(message)}")
                } else {
                    Uri.parse("whatsapp://send?text=${Uri.encode(message)}")
                }
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    `package` = "com.whatsapp"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                ToolResult(toolCallId = callId, name = name, resultText = "হোয়াটসঅ্যাপে বার্তা পাঠানো হচ্ছে: \"$message\"")
            } catch (e: Exception) {
                ToolResult(toolCallId = callId, name = name, resultText = "হোয়াটসঅ্যাপ বার্তা পাঠাতে ব্যর্থ: ${e.message}", isSuccess = false)
            }
        } else {
            // SMS
            if (!PermissionUtils.hasSms(context)) {
                return ToolResult(toolCallId = callId, name = name, resultText = "এসএমএস পাঠানোর অনুমতি দেওয়া হয়নি।", isSuccess = false)
            }
            try {
                val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(recipient, null, parts, null, null)
                ToolResult(toolCallId = callId, name = name, resultText = "$recipient নম্বরে এসএমএস সফলভাবে পাঠানো হয়েছে।")
            } catch (e: Exception) {
                ToolResult(toolCallId = callId, name = name, resultText = "এসএমএস পাঠাতে সমস্যা হয়েছে: ${e.message}", isSuccess = false)
            }
        }
    }
}
