package com.sonet.assistant.service

import android.content.Intent
import android.service.quicksettings.TileService
import com.sonet.assistant.MainActivity

class SonetTileService : TileService() {
    override fun onClick() {
        super.onClick()
        // Send wake trigger to foreground service
        val intent = Intent(this, SonetForegroundService::class.java).apply {
            action = SonetForegroundService.ACTION_TRIGGER_LISTEN
        }
        startForegroundService(intent)

        // Also open main activity or bring overlay to front
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("WAKE_TRIGGER", true)
        }
        startActivityAndCollapse(mainIntent)
    }
}
