package com.sonet.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF00E5FF)
val CyanVariant = Color(0xFF00B0FF)
val PurpleAccent = Color(0xFF7C4DFF)
val DarkBackground = Color(0xFF0B0F19)
val SurfaceDark = Color(0xFF131B2E)
val CardBackground = Color(0xFF1E293B)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
