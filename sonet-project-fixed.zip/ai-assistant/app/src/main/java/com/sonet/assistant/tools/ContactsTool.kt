package com.sonet.assistant.tools

import android.content.ContentProviderOperation
import android.content.Context
import android.provider.ContactsContract
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.util.PermissionUtils
import org.json.JSONArray
import org.json.JSONObject

class ContactsTool(private val context: Context) : Tool {
    override val name: String = "search_or_add_contact"
    override val description: String = "Search contacts by name to find phone numbers, or add a new contact."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("search", "add")))
                    put("description", "Whether to search or add a contact")
                })
                put("name", JSONObject().apply {
                    put("type", "string")
                    put("description", "Name of the contact")
                })
                put("phone_number", JSONObject().apply {
                    put("type", "string")
                    put("description", "Phone number when adding a new contact")
                })
            })
            put("required", JSONArray(listOf("action", "name")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        if (!PermissionUtils.hasContacts(context)) {
            return ToolResult(toolCallId = callId, name = name, resultText = "যোগাযোগ (Contacts) অ্যাক্সেস করার অনুমতি নেই।", isSuccess = false)
        }

        val action = arguments.optString("action", "search")
        val contactName = arguments.optString("name", "").trim()

        if (action == "add") {
            val phone = arguments.optString("phone_number", "").trim()
            if (phone.isEmpty()) {
                return ToolResult(toolCallId = callId, name = name, resultText = "যোগাযোগ যুক্ত করতে ফোন নম্বর প্রয়োজন।", isSuccess = false)
            }
            return try {
                val ops = ArrayList<ContentProviderOperation>()
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, contactName)
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build()
                )
                context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                ToolResult(toolCallId = callId, name = name, resultText = "\"$contactName\" ($phone) সফলভাবে পরিচিতিতে যুক্ত করা হয়েছে।")
            } catch (e: Exception) {
                ToolResult(toolCallId = callId, name = name, resultText = "পরিচিতি যোগ করতে সমস্যা হয়েছে: ${e.message}", isSuccess = false)
            }
        }

        // Search
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$contactName%")

        return try {
            val cursor = context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            val results = mutableListOf<String>()
            cursor?.use {
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext() && results.size < 5) {
                    val n = it.getString(nameIndex)
                    val p = it.getString(numIndex)
                    results.add("$n: $p")
                }
            }
            if (results.isNotEmpty()) {
                ToolResult(toolCallId = callId, name = name, resultText = "পাওয়া গেছে:\n" + results.joinToString("\n"))
            } else {
                ToolResult(toolCallId = callId, name = name, resultText = "\"$contactName\" নামে কোনো পরিচিতি পাওয়া যায়নি।")
            }
        } catch (e: Exception) {
            ToolResult(toolCallId = callId, name = name, resultText = "পরিচিতি খুঁজতে ত্রুটি: ${e.message}", isSuccess = false)
        }
    }
}
