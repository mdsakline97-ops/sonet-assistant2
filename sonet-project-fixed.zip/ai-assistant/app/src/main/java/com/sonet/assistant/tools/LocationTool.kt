package com.sonet.assistant.tools

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.util.PermissionUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class LocationTool(private val context: Context) : Tool {
    override val name: String = "get_location_or_navigate"
    override val description: String = "Get the current GPS location address or navigate to a destination via Google Maps."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("current_location", "navigate")))
                    put("description", "Whether to get current location or navigate")
                })
                put("destination", JSONObject().apply {
                    put("type", "string")
                    put("description", "Destination place or address to navigate to")
                })
            })
            put("required", JSONArray(listOf("action")))
        }
    }

    @SuppressLint("MissingPermission")
    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult = withContext(Dispatchers.IO) {
        val action = arguments.optString("action", "current_location")

        if (action == "navigate") {
            val dest = arguments.optString("destination", "").trim()
            if (dest.isEmpty()) {
                return@withContext ToolResult(callId, name, "গন্তব্যের নাম উল্লেখ করুন।", false)
            }
            val uri = Uri.parse("google.navigation:q=${Uri.encode(dest)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                `package` = "com.google.android.apps.maps"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return@withContext try {
                context.startActivity(intent)
                ToolResult(callId, name, "$dest এর দিকে গুগল ম্যাপে নেভিগেশন শুরু করা হয়েছে।")
            } catch (e: Exception) {
                // Fallback to browser geo
                val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(dest)}")
                context.startActivity(Intent(Intent.ACTION_VIEW, webUri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                ToolResult(callId, name, "$dest এর গুগল ম্যাপ পৃষ্ঠা খোলা হয়েছে।")
            }
        }

        // Current location
        if (!PermissionUtils.hasLocation(context)) {
            return@withContext ToolResult(callId, name, "অবস্থান (Location) দেখার অনুমতি নেই।", false)
        }

        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            val location: Location? = lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

            if (location == null) {
                return@withContext ToolResult(callId, name, "বর্তমান অবস্থান নির্ণয় করা যায়নি। অনুগ্রহ করে জিপিএস চালু রাখুন।", false)
            }

            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            val addressText = addresses?.firstOrNull()?.getAddressLine(0)
                ?: "অক্ষাংশ: ${location.latitude}, দ্রাঘিমাংশ: ${location.longitude}"

            ToolResult(callId, name, "আপনার বর্তমান অবস্থান: $addressText")
        } catch (e: Exception) {
            ToolResult(callId, name, "অবস্থান নির্ণয়ে ত্রুটি: ${e.message}", false)
        }
    }
}
