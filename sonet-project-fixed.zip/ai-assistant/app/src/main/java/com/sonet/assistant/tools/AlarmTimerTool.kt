package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.sonet.assistant.data.model.ToolResult
import org.json.JSONArray
import org.json.JSONObject

class AlarmTimerTool(private val context: Context) : Tool {
    override val name: String = "set_alarm_or_timer"
    override val description: String = "Set a system alarm or a countdown timer."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("type", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("alarm", "timer")))
                    put("description", "Whether to set an alarm or a timer")
                })
                put("hour", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Hour (0-23) for alarm")
                })
                put("minute", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Minute (0-59) for alarm")
                })
                put("seconds", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Duration in seconds for timer")
                })
                put("message", JSONObject().apply {
                    put("type", "string")
                    put("description", "Label or message for the alarm/timer")
                })
            })
            put("required", JSONArray(listOf("type")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val type = arguments.optString("type", "alarm")
        val message = arguments.optString("message", "Sonet Alert")

        return if (type == "timer") {
            val seconds = arguments.optInt("seconds", 60)
            try {
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(AlarmClock.EXTRA_MESSAGE, message)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val minutes = seconds / 60
                val sec = seconds % 60
                val durationText = if (minutes > 0) "$minutes মিনিট $sec সেকেন্ড" else "$sec সেকেন্ড"
                ToolResult(callId, name, "$durationText এর একটি টাইমার সেট করা হয়েছে।")
            } catch (e: Exception) {
                ToolResult(callId, name, "টাইমার সেট করতে সমস্যা হয়েছে: ${e.message}", false)
            }
        } else {
            // Alarm
            val hour = arguments.optInt("hour", 7)
            val minute = arguments.optInt("minute", 0)
            try {
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, message)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val formattedTime = String.format("%02d:%02d", hour, minute)
                ToolResult(callId, name, "$formattedTime টায় \"$message\" অ্যালার্ম সেট করা হয়েছে।")
            } catch (e: Exception) {
                ToolResult(callId, name, "অ্যালার্ম সেট করতে সমস্যা হয়েছে: ${e.message}", false)
            }
        }
    }
}
