package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import com.sonet.assistant.data.model.ToolResult
import org.json.JSONArray
import org.json.JSONObject

class CameraGalleryTool(private val context: Context) : Tool {
    override val name: String = "camera_or_gallery"
    override val description: String = "Open the camera to take a photo or open the photo gallery."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("take_photo", "open_gallery")))
                    put("description", "Whether to take a photo or open gallery")
                })
            })
            put("required", JSONArray(listOf("action")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val action = arguments.optString("action", "take_photo")
        return try {
            if (action == "take_photo") {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                ToolResult(callId, name, "ক্যামেরা খোলা হয়েছে।")
            } else {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse("content://media/external/images/media"), "image/*")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                ToolResult(callId, name, "গ্যালারি খোলা হয়েছে।")
            }
        } catch (e: Exception) {
            ToolResult(callId, name, "ক্যামেরা/গ্যালারি খুলতে ব্যর্থ: ${e.message}", false)
        }
    }
}
