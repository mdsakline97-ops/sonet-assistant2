package com.sonet.assistant.tools

import android.content.Context
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.service.SonetNotificationListenerService
import com.sonet.assistant.util.PermissionUtils
import org.json.JSONArray
import org.json.JSONObject

class NotificationTool(private val context: Context) : Tool {
    override val name: String = "read_notifications"
    override val description: String = "Read recent notifications that arrived on the device."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("limit", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Number of recent notifications to retrieve (default 5)")
                })
            })
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        if (!PermissionUtils.hasNotificationListener(context)) {
            return ToolResult(callId, name, "বিজ্ঞপ্তি পড়ার অনুমতি (Notification Listener) দেওয়া হয়নি।", false)
        }

        val limit = arguments.optInt("limit", 5)
        val notifications = SonetNotificationListenerService.getRecentNotifications(limit)

        if (notifications.isEmpty()) {
            return ToolResult(callId, name, "বর্তমানে কোনো নতুন নোটিফিকেশন নেই।")
        }

        val sb = StringBuilder()
        for ((idx, n) in notifications.withIndex()) {
            sb.append("${idx + 1}. [${n.appName}] ${n.title}: ${n.text}\n")
        }
        return ToolResult(callId, name, "সাম্প্রতিক নোটিফিকেশন:\n" + sb.toString().trim())
    }
}
