package com.sonet.assistant.util

import android.content.Context
import android.content.res.Configuration
import com.sonet.assistant.data.model.AppLanguage
import java.util.Locale

object LanguageManager {

    fun setAppLocale(context: Context, language: AppLanguage): Context {
        val locale = Locale(language.code)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }

    fun getLocaleForLanguage(lang: AppLanguage): Locale {
        return when (lang) {
            AppLanguage.BENGALI -> Locale("bn", "BD")
            AppLanguage.ENGLISH -> Locale.US
            AppLanguage.HINDI -> Locale("hi", "IN")
        }
    }

    fun detectLanguage(text: String): AppLanguage {
        // Bengali Unicode range: 0980–09FF
        val hasBengali = text.any { it.code in 0x0980..0x09FF }
        if (hasBengali) return AppLanguage.BENGALI

        // Devanagari (Hindi) Unicode range: 0900–097F
        val hasHindi = text.any { it.code in 0x0900..0x097F }
        if (hasHindi) return AppLanguage.HINDI

        return AppLanguage.ENGLISH
    }
}
