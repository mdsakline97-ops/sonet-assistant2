package com.sonet.assistant.data.repository

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CrashLogManager(private val context: Context) {
    private val logFile: File by lazy {
        File(context.filesDir, "sonet_diagnostics.log")
    }
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized
    fun log(tag: String, message: String, throwable: Throwable? = null) {
        try {
            val timestamp = dateFormat.format(Date())
            val stackTrace = throwable?.let { "\n" + it.stackTraceToString() } ?: ""
            val entry = "[$timestamp] [$tag] $message$stackTrace\n"

            // Keep max ~200KB log file
            if (logFile.exists() && logFile.length() > 200 * 1024) {
                val lines = logFile.readLines()
                val trimmed = lines.takeLast(lines.size / 2)
                logFile.writeText(trimmed.joinToString("\n") + "\n")
            }

            logFile.appendText(entry)
        } catch (_: Exception) {}
    }

    fun getLogs(): String {
        return try {
            if (logFile.exists()) logFile.readText() else "No logs yet."
        } catch (e: Exception) {
            "Error reading logs: ${e.message}"
        }
    }

    fun clearLogs() {
        try {
            if (logFile.exists()) logFile.delete()
        } catch (_: Exception) {}
    }
}
