package com.sonet.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.sonet.assistant.MainActivity
import com.sonet.assistant.R
import com.sonet.assistant.data.model.AssistantState
import com.sonet.assistant.data.model.ChatMessage
import com.sonet.assistant.data.model.ToolCall
import com.sonet.assistant.data.model.WakeMethod
import com.sonet.assistant.data.repository.CrashLogManager
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.data.repository.TaskRepository
import com.sonet.assistant.providers.ProviderManager
import com.sonet.assistant.tools.ToolDispatcher
import com.sonet.assistant.tools.ToolRegistry
import com.sonet.assistant.util.PermissionUtils
import com.sonet.assistant.voice.ClapDetector
import com.sonet.assistant.voice.SoundFeedbackManager
import com.sonet.assistant.voice.SpeechRecognitionManager
import com.sonet.assistant.voice.TextToSpeechManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SonetForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var prefsRepo: PreferencesRepository
    private lateinit var taskRepo: TaskRepository
    private lateinit var crashLogger: CrashLogManager
    private lateinit var toolRegistry: ToolRegistry
    private lateinit var toolDispatcher: ToolDispatcher
    private lateinit var providerManager: ProviderManager
    private lateinit var soundFeedback: SoundFeedbackManager
    private lateinit var ttsManager: TextToSpeechManager
    private lateinit var speechManager: SpeechRecognitionManager
    private lateinit var clapDetector: ClapDetector
    private lateinit var overlayManager: OverlayManager

    private var isPaused = false
    private var pendingToolCall: ToolCall? = null
    private val conversationHistory = mutableListOf<ChatMessage>()

    companion object {
        const val CHANNEL_ID = "sonet_foreground_service_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_SERVICE = "com.sonet.action.START"
        const val ACTION_TRIGGER_LISTEN = "com.sonet.action.LISTEN"
        const val ACTION_PAUSE = "com.sonet.action.PAUSE"
        const val ACTION_RESUME = "com.sonet.action.RESUME"
        const val ACTION_STOP = "com.sonet.action.STOP"

        @Volatile
        var instance: SonetForegroundService? = null

        private val _assistantStateFlow = MutableStateFlow(AssistantState.IDLE)
        val assistantStateFlow: StateFlow<AssistantState> = _assistantStateFlow.asStateFlow()

        private val _lastUserSpeechFlow = MutableStateFlow("")
        val lastUserSpeechFlow: StateFlow<String> = _lastUserSpeechFlow.asStateFlow()

        private val _lastAssistantSpeechFlow = MutableStateFlow("")
        val lastAssistantSpeechFlow: StateFlow<String> = _lastAssistantSpeechFlow.asStateFlow()

        fun isServiceRunning(): Boolean = instance != null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this

        prefsRepo = PreferencesRepository(this)
        taskRepo = TaskRepository(this)
        crashLogger = CrashLogManager(this)
        toolRegistry = ToolRegistry(this, taskRepo)
        toolDispatcher = ToolDispatcher(toolRegistry)
        providerManager = ProviderManager(this, prefsRepo, taskRepo, crashLogger, toolRegistry, toolDispatcher)
        soundFeedback = SoundFeedbackManager()

        ttsManager = TextToSpeechManager(this) { success ->
            if (success) {
                ttsManager.pitch = prefsRepo.getVoicePitch()
                ttsManager.speechRate = prefsRepo.getSpeechRate()
            }
        }
        ttsManager.onSpeechCompleted = {
            onTtsCompleted()
        }

        speechManager = SpeechRecognitionManager(this).apply {
            listener = createSpeechListener()
        }

        clapDetector = ClapDetector(this) {
            if (!isPaused) {
                triggerWakeUp()
            }
        }
        clapDetector.sensitivity = prefsRepo.getClapSensitivity()

        overlayManager = OverlayManager(
            context = this,
            onStopClicked = { stopAll() },
            onConfirmClicked = { confirmed -> handleConfirmation(confirmed) }
        )

        createNotificationChannel()
        startInForeground()

        // Start clap detector if wake method is CLAP
        if (prefsRepo.getWakeMethod() == WakeMethod.CLAP && PermissionUtils.hasRecordAudio(this)) {
            clapDetector.start()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TRIGGER_LISTEN -> {
                triggerWakeUp()
            }
            ACTION_PAUSE -> {
                isPaused = true
                clapDetector.stop()
                stopAll()
                updateNotification()
            }
            ACTION_RESUME -> {
                isPaused = false
                if (prefsRepo.getWakeMethod() == WakeMethod.CLAP) {
                    clapDetector.start()
                }
                updateNotification()
            }
            ACTION_STOP -> {
                stopAll()
            }
            ACTION_START_SERVICE -> {
                // Ensure running
            }
        }
        return START_STICKY
    }

    fun triggerWakeUp() {
        if (isPaused) return
        mainHandler.post {
            soundFeedback.playWakeBeep()
            overlayManager.show()
            updateState(AssistantState.LISTENING)
            overlayManager.updateTranscript("")
            overlayManager.updateResponse("")
            speechManager.startListening(prefsRepo.getLanguage())
        }
    }

    private fun handleConfirmation(confirmed: Boolean) {
        val toolCall = pendingToolCall
        pendingToolCall = null
        if (confirmed && toolCall != null) {
            updateState(AssistantState.THINKING)
            serviceScope.launch {
                val reply = providerManager.processUserSpeech("", conversationHistory, confirmedToolCall = toolCall)
                speakReply(reply.spokenText)
            }
        } else {
            speakReply("কমান্ডটি বাতিল করা হয়েছে।")
        }
    }

    fun speakNotification(text: String) {
        serviceScope.launch {
            speakReply(text)
        }
    }

    private fun createSpeechListener(): SpeechRecognitionManager.Listener {
        return object : SpeechRecognitionManager.Listener {
            override fun onReady() {
                updateState(AssistantState.LISTENING)
            }

            override fun onRmsChanged(rmsdB: Float) {}

            override fun onPartial(text: String) {
                _lastUserSpeechFlow.value = text
                overlayManager.updateTranscript(text)
            }

            override fun onResult(text: String) {
                _lastUserSpeechFlow.value = text
                overlayManager.updateTranscript(text)

                // Check stop phrase
                val lower = text.lowercase().trim()
                if (lower == "stop" || lower == "থামো" || lower == "বন্ধ করো" || lower == "থেমে যাও") {
                    speakReply("ঠিক আছে, থামছি।")
                    return
                }

                // If user is confirming a pending action by voice
                if (pendingToolCall != null) {
                    if (lower.contains("হ্যাঁ") || lower.contains("yes") || lower.contains("করো") || lower.contains("ঠিক আছে")) {
                        handleConfirmation(true)
                        return
                    } else if (lower.contains("না") || lower.contains("no") || lower.contains("বাতিল")) {
                        handleConfirmation(false)
                        return
                    }
                }

                updateState(AssistantState.THINKING)
                processSpeech(text)
            }

            override fun onError(error: String) {
                if (_assistantStateFlow.value == AssistantState.LISTENING) {
                    updateState(AssistantState.IDLE)
                }
            }
        }
    }

    private fun processSpeech(userText: String) {
        serviceScope.launch {
            try {
                val reply = providerManager.processUserSpeech(userText, conversationHistory)
                if (reply.pendingConfirmationToolCall != null) {
                    pendingToolCall = reply.pendingConfirmationToolCall
                    overlayManager.requestConfirmation(reply.confirmationPrompt ?: "নিশ্চিত করুন")
                }
                speakReply(reply.spokenText)
            } catch (e: Exception) {
                crashLogger.log("PROCESS_SPEECH", "ত্রুটি: ${e.message}", e)
                speakReply("একটি ত্রুটি হয়েছে: ${e.message}")
            }
        }
    }

    private fun speakReply(text: String) {
        _lastAssistantSpeechFlow.value = text
        overlayManager.updateResponse(text)
        updateState(AssistantState.SPEAKING)
        ttsManager.speak(text)
    }

    private fun onTtsCompleted() {
        mainHandler.post {
            updateState(AssistantState.IDLE)
            // If continuous conversation mode is active, automatically listen again!
            if (prefsRepo.isContinuousMode() && !isPaused && pendingToolCall == null && overlayManager.isVisible()) {
                mainHandler.postDelayed({
                    if (_assistantStateFlow.value == AssistantState.IDLE && overlayManager.isVisible()) {
                        triggerWakeUp()
                    }
                }, 400)
            } else {
                mainHandler.postDelayed({
                    if (_assistantStateFlow.value == AssistantState.IDLE) {
                        overlayManager.hide()
                    }
                }, 3500)
            }
        }
    }

    fun stopAll() {
        mainHandler.post {
            speechManager.stopListening()
            ttsManager.stop()
            updateState(AssistantState.IDLE)
            overlayManager.hide()
            pendingToolCall = null
        }
    }

    private fun updateState(state: AssistantState) {
        _assistantStateFlow.value = state
        overlayManager.updateState(state)
    }

    private fun startInForeground() {
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            crashLogger.log("FOREGROUND", "Failed to startForeground: ${e.message}", e)
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val talkIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, SonetForegroundService::class.java).apply { action = ACTION_TRIGGER_LISTEN },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeAction = if (isPaused) {
            val resumeIntent = PendingIntent.getService(
                this,
                2,
                Intent(this, SonetForegroundService::class.java).apply { action = ACTION_RESUME },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationCompat.Action(0, "চালু করুন", resumeIntent)
        } else {
            val pauseIntent = PendingIntent.getService(
                this,
                3,
                Intent(this, SonetForegroundService::class.java).apply { action = ACTION_PAUSE },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationCompat.Action(0, "বিরতি", pauseIntent)
        }

        val statusText = if (isPaused) "সোনেট বিরতিতে আছে (স্থগিত)" else "বলুন \"সোনেট\" বা দুইবার তালি দিন"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("সোনেট এআই সহায়ক")
            .setContentText(statusText)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "কথা বলুন", talkIntent)
            .addAction(pauseResumeAction)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "সোনেট ব্যাকগ্রাউন্ড সেবা",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "সোনেটকে সর্বদা সজাগ রাখে"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clapDetector.stop()
        speechManager.stopListening()
        ttsManager.shutdown()
        soundFeedback.release()
        overlayManager.hide()
        serviceScope.cancel()
        if (instance == this) instance = null
    }
}
