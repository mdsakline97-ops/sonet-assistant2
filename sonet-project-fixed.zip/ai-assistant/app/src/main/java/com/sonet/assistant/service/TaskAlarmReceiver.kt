package com.sonet.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf

class TaskAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra("TASK_ID", -1L)
        val title = intent.getStringExtra("TASK_TITLE") ?: "Sonet Task"
        val desc = intent.getStringExtra("TASK_DESC") ?: ""

        val workRequest = OneTimeWorkRequestBuilder<TaskWorker>()
            .setInputData(
                workDataOf(
                    "TASK_ID" to taskId,
                    "TASK_TITLE" to title,
                    "TASK_DESC" to desc
                )
            )
            .build()

        WorkManager.getInstance(context).enqueue(workRequest)
    }
}
