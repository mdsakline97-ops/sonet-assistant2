package com.sonet.assistant.providers

import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.ChatMessage
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.model.Role
import com.sonet.assistant.data.model.ToolCall
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiProvider : AiProvider {
    override val type: ProviderType = ProviderType.GEMINI

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun chat(
        config: AiProviderConfig,
        systemPrompt: String,
        messages: List<ChatMessage>,
        toolsJson: Any?
    ): ProviderResponse = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) {
            throw IOException("Google Gemini API Key খালি। অনুগ্রহ করে সেটিংসে সঠিক API Key দিন।")
        }

        val baseUrl = config.baseUrl.trimEnd('/')
        val model = config.modelName.trim().ifEmpty { "gemini-1.5-flash" }
        val url = "$baseUrl/v1beta/models/$model:generateContent?key=${config.apiKey.trim()}"

        val rootJson = JSONObject()

        // System Instruction
        if (systemPrompt.isNotBlank()) {
            val sysObj = JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", systemPrompt) })
                })
            }
            rootJson.put("systemInstruction", sysObj)
        }

        // Contents
        val contentsArray = JSONArray()
        for (msg in messages) {
            val contentObj = JSONObject()
            val roleStr = when (msg.role) {
                Role.USER -> "user"
                Role.ASSISTANT -> "model"
                Role.SYSTEM -> "user"
                Role.TOOL -> "function"
            }
            contentObj.put("role", roleStr)

            val partsArray = JSONArray()
            if (msg.role == Role.TOOL && msg.name != null) {
                val respPart = JSONObject().apply {
                    put("functionResponse", JSONObject().apply {
                        put("name", msg.name)
                        put("response", JSONObject().apply {
                            put("name", msg.name)
                            put("content", msg.content)
                        })
                    })
                }
                partsArray.put(respPart)
            } else if (msg.toolCalls.isNotEmpty()) {
                for (tc in msg.toolCalls) {
                    val callPart = JSONObject().apply {
                        val fnObj = JSONObject().apply {
                            put("name", tc.name)
                            put("args", JSONObject(tc.arguments))
                        }
                        put("functionCall", fnObj)
                    }
                    partsArray.put(callPart)
                }
                if (msg.content.isNotBlank()) {
                    partsArray.put(JSONObject().apply { put("text", msg.content) })
                }
            } else {
                partsArray.put(JSONObject().apply { put("text", msg.content) })
            }
            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
        }
        rootJson.put("contents", contentsArray)

        // Tools
        if (toolsJson is JSONArray && toolsJson.length() > 0) {
            rootJson.put("tools", toolsJson)
        }

        val request = Request.Builder()
            .url(url)
            .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            val errorMsg = parseErrorMessage(response.code, responseBody, model)
            throw IOException(errorMsg)
        }

        val respJson = JSONObject(responseBody)
        val candidates = respJson.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            return@withContext ProviderResponse(content = "কোনো উত্তর পাওয়া যায়নি।")
        }

        val firstCandidate = candidates.getJSONObject(0)
        val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")

        val textSb = StringBuilder()
        val toolCalls = mutableListOf<ToolCall>()

        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("text")) {
                    textSb.append(part.getString("text"))
                }
                if (part.has("functionCall")) {
                    val fn = part.getJSONObject("functionCall")
                    val fnName = fn.getString("name")
                    val argsObj = fn.optJSONObject("args") ?: JSONObject()
                    toolCalls.add(
                        ToolCall(
                            id = "call_${System.currentTimeMillis()}_$i",
                            name = fnName,
                            arguments = argsObj.toString()
                        )
                    )
                }
            }
        }

        ProviderResponse(
            content = textSb.toString().trim(),
            toolCalls = toolCalls,
            rawJson = responseBody
        )
    }

    override suspend fun listModels(config: AiProviderConfig): List<String> = withContext(Dispatchers.IO) {
        val baseUrl = config.baseUrl.trimEnd('/')
        val url = "$baseUrl/v1beta/models?key=${config.apiKey.trim()}"
        val request = Request.Builder().url(url).get().build()
        val response = httpClient.newCall(request).execute()
        val body = response.body?.string() ?: ""
        if (!response.isSuccessful) {
            throw IOException(parseErrorMessage(response.code, body, "models"))
        }
        val json = JSONObject(body)
        val models = json.optJSONArray("models") ?: JSONArray()
        val list = mutableListOf<String>()
        for (i in 0 until models.length()) {
            val item = models.getJSONObject(i)
            val name = item.optString("name").removePrefix("models/")
            val supported = item.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (supported.contains("generateContent")) {
                list.add(name)
            }
        }
        list
    }

    override suspend fun testConnection(config: AiProviderConfig): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val models = listModels(config)
            if (models.isNotEmpty()) {
                Pair(true, "সংযোগ সফল! মডেল সংখ্যা: ${models.size} (ডিফল্ট: ${config.modelName})")
            } else {
                Pair(true, "সংযোগ সফল হয়েছে।")
            }
        } catch (e: Exception) {
            Pair(false, e.message ?: "সংযোগ ব্যর্থ")
        }
    }

    private fun parseErrorMessage(code: Int, body: String, model: String): String {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message") ?: body
        } catch (_: Exception) {
            body
        }
        return when (code) {
            400 -> "জেমিনাই ত্রুটি (400): অনুরোধটি সঠিক ছিল না। বিস্তারিত: $detail"
            403 -> "জেমিনাই অনুমোদন ব্যর্থ (403): আপনার এপিআই কি সঠিক নয় বা মেয়াদ শেষ। Google AI Studio থেকে নতুন কি নিন।"
            404 -> "জেমিনাই মডেল খুঁজে পাওয়া যায়নি (404): \"$model\" মডেলটি অবৈধ। সেটিংসে 'মডেল তালিকা আনুন' চাপুন বা 'gemini-1.5-flash' দিন।"
            429 -> "জেমিনাই সীমা পার হয়েছে (429): ফ্রি কোটা শেষ বা রেট লিমিট হয়েছে। পরবর্তী প্রোভাইডারে স্যুইচ করা হচ্ছে।"
            500, 503 -> "গুগল সার্ভার ত্রুটি ($code): গুগল সার্ভারে অস্থায়ী সমস্যা হচ্ছে।"
            else -> "জেমিনাই ত্রুটি ($code): $detail"
        }
    }
}
