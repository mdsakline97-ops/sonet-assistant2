package com.sonet.assistant.providers

import android.content.Context
import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.ChatMessage
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.model.Role
import com.sonet.assistant.data.model.ToolCall
import com.sonet.assistant.data.repository.CrashLogManager
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.data.repository.TaskRepository
import com.sonet.assistant.tools.ToolDispatcher
import com.sonet.assistant.tools.ToolRegistry
import com.sonet.assistant.util.OfflineCommandHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AssistantReply(
    val spokenText: String,
    val pendingConfirmationToolCall: ToolCall? = null,
    val confirmationPrompt: String? = null,
    val providerUsed: String = ""
)

class ProviderManager(
    private val context: Context,
    private val prefsRepo: PreferencesRepository,
    private val taskRepo: TaskRepository,
    private val crashLogger: CrashLogManager,
    private val toolRegistry: ToolRegistry,
    private val toolDispatcher: ToolDispatcher
) {
    private val providers = mapOf(
        ProviderType.GEMINI to GeminiProvider(),
        ProviderType.OPENAI_COMPATIBLE to OpenAiCompatibleProvider(),
        ProviderType.CLAUDE to ClaudeProvider()
    )

    fun getProvider(type: ProviderType): AiProvider = providers[type] ?: providers.getValue(ProviderType.GEMINI)

    suspend fun processUserSpeech(
        userText: String,
        conversationHistory: List<ChatMessage>,
        confirmedToolCall: ToolCall? = null
    ): AssistantReply = withContext(Dispatchers.IO) {

        // 1. If user is executing a previously confirmed tool call
        if (confirmedToolCall != null) {
            val result = toolDispatcher.execute(confirmedToolCall, userConfirmed = true)
            val updatedHistory = conversationHistory.toMutableList().apply {
                add(
                    ChatMessage(
                        role = Role.TOOL,
                        content = result.resultText,
                        toolCallId = confirmedToolCall.id,
                        name = confirmedToolCall.name
                    )
                )
            }
            // Generate final confirmation speech
            return@withContext runProviderChain(updatedHistory, "নিশ্চিতকৃত কমান্ড সম্পন্ন হয়েছে।")
        }

        // 2. Offline fast-path
        val offlineResult = OfflineCommandHandler.tryHandleOffline(context, userText)
        if (offlineResult.handled) {
            taskRepo.saveConversation("USER", userText, "OFFLINE")
            taskRepo.saveConversation("ASSISTANT", offlineResult.responseSpeech, "OFFLINE")
            return@withContext AssistantReply(
                spokenText = offlineResult.responseSpeech,
                providerUsed = "লোকাল অফলাইন"
            )
        }

        // 3. Online AI provider execution
        val messages = conversationHistory.toMutableList().apply {
            add(ChatMessage(Role.USER, userText))
        }

        runProviderChain(messages, userText)
    }

    private suspend fun runProviderChain(
        messages: MutableList<ChatMessage>,
        originalUserQuery: String
    ): AssistantReply {
        val configs = prefsRepo.getProviderConfigs().filter { it.isEnabled && it.apiKey.isNotBlank() }
        val primaryType = prefsRepo.getPrimaryProvider()

        // Sort so primary comes first, then by priority
        val sortedConfigs = configs.sortedWith(
            compareBy<AiProviderConfig> { it.type != primaryType }
                .thenBy { it.priority }
        )

        if (sortedConfigs.isEmpty()) {
            val noKeyMsg = "কোনো এআই প্রোভাইডারের API Key সংরক্ষিত নেই। দয়া করে অ্যাপের 'সেটিংস' এ গিয়ে Google Gemini বা Groq এর ফ্রি API Key যুক্ত করুন।"
            taskRepo.saveConversation("USER", originalUserQuery, "NONE")
            taskRepo.saveConversation("ASSISTANT", noKeyMsg, "NONE")
            return AssistantReply(spokenText = noKeyMsg, providerUsed = "NONE")
        }

        // Build system prompt with long-term memories
        val memories = taskRepo.getMemoriesSnapshot()
        val memoryBlock = if (memories.isNotEmpty()) {
            "\n\n[USER SAVED FACTS & PREFERENCES]:\n" + memories.joinToString("\n") { "- ${it.key}: ${it.value}" }
        } else ""

        val systemPrompt = prefsRepo.getSystemPrompt() + memoryBlock

        var lastError: Exception? = null

        for (config in sortedConfigs) {
            val provider = getProvider(config.type)
            val toolsJson = when (config.type) {
                ProviderType.GEMINI -> toolRegistry.getGeminiToolsJson()
                ProviderType.OPENAI_COMPATIBLE -> toolRegistry.getOpenAiToolsJson()
                ProviderType.CLAUDE -> toolRegistry.getClaudeToolsJson()
            }

            try {
                crashLogger.log("AI_CALL", "Calling ${config.type.displayName} model ${config.modelName}")
                val response = provider.chat(config, systemPrompt, messages, toolsJson)

                // Check for native tool calls
                if (response.toolCalls.isNotEmpty()) {
                    val firstToolCall = response.toolCalls.first()
                    // Check if confirmation is required
                    if (prefsRepo.isConfirmSensitive()) {
                        val previewResult = toolDispatcher.execute(firstToolCall, userConfirmed = false)
                        if (previewResult.requiresConfirmation) {
                            val prompt = previewResult.confirmationPrompt ?: "আপনি কি এটি নিশ্চিত করতে চান?"
                            return AssistantReply(
                                spokenText = prompt,
                                pendingConfirmationToolCall = firstToolCall,
                                confirmationPrompt = prompt,
                                providerUsed = config.type.displayName
                            )
                        }
                    }

                    // Execute tool directly
                    val execResult = toolDispatcher.execute(firstToolCall, userConfirmed = true)
                    messages.add(
                        ChatMessage(
                            role = Role.ASSISTANT,
                            content = response.content,
                            toolCalls = response.toolCalls
                        )
                    )
                    messages.add(
                        ChatMessage(
                            role = Role.TOOL,
                            content = execResult.resultText,
                            toolCallId = firstToolCall.id,
                            name = firstToolCall.name
                        )
                    )

                    // Follow-up chat to get conversational answer
                    val followUp = provider.chat(config, systemPrompt, messages, null)
                    val finalSpeech = followUp.content.ifEmpty { execResult.resultText }

                    taskRepo.saveConversation("USER", originalUserQuery, config.type.displayName)
                    taskRepo.saveConversation("ASSISTANT", finalSpeech, config.type.displayName)

                    return AssistantReply(
                        spokenText = finalSpeech,
                        providerUsed = config.type.displayName
                    )
                }

                // Check for fallback action in text
                val fallbackAction = toolDispatcher.parseFallbackAction(response.content)
                if (fallbackAction != null) {
                    val execResult = toolDispatcher.execute(fallbackAction, userConfirmed = true)
                    val combinedSpeech = "${execResult.resultText}"
                    taskRepo.saveConversation("USER", originalUserQuery, config.type.displayName)
                    taskRepo.saveConversation("ASSISTANT", combinedSpeech, config.type.displayName)
                    return AssistantReply(spokenText = combinedSpeech, providerUsed = config.type.displayName)
                }

                // Normal speech response
                val cleanContent = response.content.trim()
                taskRepo.saveConversation("USER", originalUserQuery, config.type.displayName)
                taskRepo.saveConversation("ASSISTANT", cleanContent, config.type.displayName)

                return AssistantReply(
                    spokenText = cleanContent,
                    providerUsed = config.type.displayName
                )
            } catch (e: Exception) {
                lastError = e
                crashLogger.log("AI_FAIL", "${config.type.displayName} ব্যর্থ হয়েছে: ${e.message}", e)
                // Continue loop to try next fallback provider
            }
        }

        // All configured providers failed
        val failureMessage = "দুঃখিত, কোনো এআই প্রোভাইডারের সংযোগ কাজ করছে না। ত্রুটি: ${lastError?.message ?: "অজানা সমস্যা"}।"
        taskRepo.saveConversation("USER", originalUserQuery, "ERROR")
        taskRepo.saveConversation("ASSISTANT", failureMessage, "ERROR")
        return AssistantReply(spokenText = failureMessage, providerUsed = "FAIL")
    }
}
