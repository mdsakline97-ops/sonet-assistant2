package com.sonet.assistant.data.db.dao

import androidx.room.*
import com.sonet.assistant.data.db.entity.MemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories")
    suspend fun getMemoriesSnapshot(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE `key` LIKE '%' || :keyword || '%' OR value LIKE '%' || :keyword || '%'")
    suspend fun searchMemories(keyword: String): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Delete
    suspend fun deleteMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemoryById(id: Long)
}
