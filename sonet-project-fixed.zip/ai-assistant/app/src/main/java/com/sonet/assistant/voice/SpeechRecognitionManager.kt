package com.sonet.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.sonet.assistant.data.model.AppLanguage
import com.sonet.assistant.util.PermissionUtils

class SpeechRecognitionManager(private val context: Context) {

    interface Listener {
        fun onReady()
        fun onRmsChanged(rmsdB: Float)
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onError(error: String)
    }

    var listener: Listener? = null
    private var recognizer: SpeechRecognizer? = null
    private var isListening = false
    private val mainHandler = Handler(Looper.getMainLooper())

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(language: AppLanguage) {
        if (!PermissionUtils.hasRecordAudio(context)) {
            listener?.onError("মাইক্রোফোনের অনুমতি প্রয়োজন")
            return
        }

        mainHandler.post {
            stopListening()

            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createListener())
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.localeTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language.localeTag)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }

                recognizer?.startListening(intent)
                isListening = true
            } catch (e: Exception) {
                isListening = false
                listener?.onError("ভয়েস রিকগনিশন শুরু করা যায়নি: ${e.message}")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                if (isListening) {
                    recognizer?.stopListening()
                }
                recognizer?.destroy()
            } catch (_: Exception) {}
            recognizer = null
            isListening = false
        }
    }

    private fun createListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listener?.onReady()
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                listener?.onRmsChanged(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                isListening = false
            }

            override fun onError(error: Int) {
                isListening = false
                val errorMsg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "কোনো কথা শোনা যায়নি।"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "সময় পার হয়ে গেছে।"
                    SpeechRecognizer.ERROR_AUDIO -> "অডিও ত্রুটি।"
                    SpeechRecognizer.ERROR_CLIENT -> "রিকগনিশন ক্লায়েন্ট ত্রুটি।"
                    SpeechRecognizer.ERROR_NETWORK -> "ইন্টারনেট সংযোগ সমস্যা।"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ইন্টারনেট টাইমআউট।"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন অনুমতি নেই।"
                    else -> "ভয়েস ত্রুটি ($error)"
                }
                listener?.onError(errorMsg)
            }

            override fun onResults(results: Bundle?) {
                isListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotBlank()) {
                    listener?.onResult(text)
                } else {
                    listener?.onError("কোনো কথা বোঝা যায়নি।")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""
                if (text.isNotBlank()) {
                    listener?.onPartial(text)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }
}
