package com.sonet.assistant.tools

import android.content.Context
import com.sonet.assistant.data.model.ToolResult
import com.sonet.assistant.service.SonetAccessibilityService
import com.sonet.assistant.util.PermissionUtils
import org.json.JSONArray
import org.json.JSONObject

class ScreenActionTool(private val context: Context) : Tool {
    override val name: String = "screen_action"
    override val description: String = "Perform screen actions using Accessibility Service: back, home, scroll_down, scroll_up, type_text, or read_screen."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("back", "home", "scroll_down", "scroll_up", "type_text", "read_screen")))
                    put("description", "Action to perform on screen")
                })
                put("text", JSONObject().apply {
                    put("type", "string")
                    put("description", "Text to type when action is type_text")
                })
            })
            put("required", JSONArray(listOf("action")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        if (!PermissionUtils.hasAccessibilityService(context)) {
            return ToolResult(callId, name, "অ্যাক্সেসিবিলিটি সার্ভিস চালু নেই। অনুগ্রহ করে সেটিংসে গিয়ে সোনেট সার্ভিস চালু করুন।", false)
        }

        val action = arguments.optString("action")
        return when (action) {
            "back" -> {
                val ok = SonetAccessibilityService.performGlobalBack()
                ToolResult(callId, name, if (ok) "পেছনে ফিরে যাওয়া হয়েছে।" else "কাজটি সম্পন্ন করা যায়নি।")
            }
            "home" -> {
                val ok = SonetAccessibilityService.performGlobalHome()
                ToolResult(callId, name, if (ok) "হোম স্ক্রিনে যাওয়া হয়েছে।" else "কাজটি সম্পন্ন করা যায়নি।")
            }
            "scroll_down" -> {
                val ok = SonetAccessibilityService.scroll(true)
                ToolResult(callId, name, if (ok) "নিচে স্ক্রোল করা হয়েছে।" else "স্ক্রোল করা যায়নি।")
            }
            "scroll_up" -> {
                val ok = SonetAccessibilityService.scroll(false)
                ToolResult(callId, name, if (ok) "উপরে স্ক্রোল করা হয়েছে।" else "স্ক্রোল করা যায়নি।")
            }
            "type_text" -> {
                val text = arguments.optString("text", "")
                val ok = SonetAccessibilityService.typeText(text)
                ToolResult(callId, name, if (ok) "\"$text\" টাইপ করা হয়েছে।" else "টাইপ করা যায়নি।")
            }
            "read_screen" -> {
                val screenContent = SonetAccessibilityService.readScreenText()
                if (screenContent.isNotBlank()) {
                    ToolResult(callId, name, "স্ক্রিনের লেখা:\n$screenContent")
                } else {
                    ToolResult(callId, name, "স্ক্রিনে কোনো পাঠ্য খুঁজে পাওয়া যায়নি।")
                }
            }
            else -> ToolResult(callId, name, "অজানা স্ক্রিন অ্যাকশন: $action", false)
        }
    }
}
