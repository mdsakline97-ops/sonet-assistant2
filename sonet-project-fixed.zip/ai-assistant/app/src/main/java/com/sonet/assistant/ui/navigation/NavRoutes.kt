package com.sonet.assistant.ui.navigation

sealed class Screen(val route: String) {
    data object Onboarding : Screen("onboarding")
    data object Permissions : Screen("permissions")
    data object Home : Screen("home")
    data object Tasks : Screen("tasks")
    data object MemoryNotes : Screen("memory_notes")
    data object Settings : Screen("settings")
    data object ProviderSettings : Screen("provider_settings")
    data object Diagnostics : Screen("diagnostics")
    data object ClapTester : Screen("clap_tester")
}
