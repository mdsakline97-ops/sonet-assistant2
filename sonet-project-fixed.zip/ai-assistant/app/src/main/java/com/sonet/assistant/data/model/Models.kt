package com.sonet.assistant.data.model

enum class Role {
    USER,
    ASSISTANT,
    SYSTEM,
    TOOL
}

data class ChatMessage(
    val role: Role,
    val content: String,
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
    val name: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class ToolCall(
    val id: String,
    val name: String,
    val arguments: String // JSON string
)

data class ToolResult(
    val toolCallId: String,
    val name: String,
    val resultText: String,
    val isSuccess: Boolean = true,
    val requiresConfirmation: Boolean = false,
    val confirmationPrompt: String? = null
)

enum class ProviderType(val displayName: String, val defaultBaseUrl: String, val defaultModel: String) {
    GEMINI("Google Gemini", "https://generativelanguage.googleapis.com", "gemini-1.5-flash"),
    OPENAI_COMPATIBLE("OpenAI / Groq / DeepSeek", "https://api.groq.com/openai/v1", "llama-3.1-70b-versatile"),
    CLAUDE("Anthropic Claude", "https://api.anthropic.com", "claude-3-haiku-20240307")
}

data class AiProviderConfig(
    val type: ProviderType,
    val apiKey: String,
    val baseUrl: String = type.defaultBaseUrl,
    val modelName: String = type.defaultModel,
    val isEnabled: Boolean = true,
    val priority: Int = 0
)

enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

enum class WakeMethod(val id: String) {
    CLAP("clap"),
    VOICE("voice"),
    BUTTON_ONLY("button_only")
}

enum class AppLanguage(val code: String, val localeTag: String, val displayName: String) {
    BENGALI("bn", "bn-BD", "বাংলা"),
    ENGLISH("en", "en-US", "English"),
    HINDI("hi", "hi-IN", "हिन्दी")
}
