package com.sonet.assistant.tools

import android.content.Context
import com.sonet.assistant.data.repository.TaskRepository
import org.json.JSONArray
import org.json.JSONObject

class ToolRegistry(
    private val context: Context,
    private val taskRepository: TaskRepository
) {
    private val tools = mutableMapOf<String, Tool>()

    init {
        register(AppControlTool(context))
        register(CallPhoneTool(context))
        register(SmsWhatsAppTool(context))
        register(ContactsTool(context))
        register(DeviceControlTool(context))
        register(AlarmTimerTool(context))
        register(WebSearchTool(context))
        register(LocationTool(context))
        register(CameraGalleryTool(context))
        register(NotificationTool(context))
        register(ScreenActionTool(context))
        register(ClipboardTool(context))
        register(TaskMemoryTool(taskRepository))
    }

    fun register(tool: Tool) {
        tools[tool.name] = tool
    }

    fun getTool(name: String): Tool? = tools[name]

    fun getAllTools(): List<Tool> = tools.values.toList()

    /**
     * Gemini API tools payload:
     * [{"functionDeclarations": [...]}]
     */
    fun getGeminiToolsJson(): JSONArray {
        val decls = JSONArray()
        for (tool in tools.values) {
            val fn = JSONObject().apply {
                put("name", tool.name)
                put("description", tool.description)
                put("parameters", tool.getParametersSchema())
            }
            decls.put(fn)
        }
        val wrapper = JSONObject().apply {
            put("functionDeclarations", decls)
        }
        return JSONArray().apply { put(wrapper) }
    }

    /**
     * OpenAI / Groq / DeepSeek tools payload:
     * [{"type": "function", "function": {...}}]
     */
    fun getOpenAiToolsJson(): JSONArray {
        val array = JSONArray()
        for (tool in tools.values) {
            val item = JSONObject().apply {
                put("type", "function")
                put("function", JSONObject().apply {
                    put("name", tool.name)
                    put("description", tool.description)
                    put("parameters", tool.getParametersSchema())
                })
            }
            array.put(item)
        }
        return array
    }

    /**
     * Anthropic Claude tools payload:
     * [{"name": "...", "description": "...", "input_schema": {...}}]
     */
    fun getClaudeToolsJson(): JSONArray {
        val array = JSONArray()
        for (tool in tools.values) {
            val item = JSONObject().apply {
                put("name", tool.name)
                put("description", tool.description)
                put("input_schema", tool.getParametersSchema())
            }
            array.put(item)
        }
        return array
    }
}
