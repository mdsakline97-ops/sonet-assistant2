package com.sonet.assistant.tools

import com.sonet.assistant.data.model.ToolResult
import org.json.JSONObject

interface Tool {
    val name: String
    val description: String
    val isSensitive: Boolean
        get() = false

    /**
     * Returns JSON Schema definition for tool parameters:
     * e.g.
     * {
     *   "type": "object",
     *   "properties": {
     *     "phone_number": { "type": "string", "description": "Phone number to call" }
     *   },
     *   "required": ["phone_number"]
     * }
     */
    fun getParametersSchema(): JSONObject

    suspend fun execute(callId: String, arguments: JSONObject): ToolResult

    fun getConfirmationMessage(arguments: JSONObject): String {
        return "আপনি কি এই কাজটি করতে নিশ্চিত?"
    }
}
