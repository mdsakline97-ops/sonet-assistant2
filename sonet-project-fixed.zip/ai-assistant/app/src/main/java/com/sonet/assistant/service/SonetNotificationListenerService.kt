package com.sonet.assistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class CapturedNotification(
    val appName: String,
    val title: String,
    val text: String,
    val timestamp: Long
)

class SonetNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val pkg = sbn.packageName ?: ""

        if (title.isBlank() && text.isBlank()) return
        if (pkg == packageName) return // Ignore own notifications

        val appLabel = try {
            val pm = packageManager
            val info = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkg
        }

        synchronized(recentNotifications) {
            recentNotifications.add(0, CapturedNotification(appLabel, title, text, System.currentTimeMillis()))
            if (recentNotifications.size > 50) {
                recentNotifications.removeAt(recentNotifications.lastIndex)
            }
        }
    }

    companion object {
        private val recentNotifications = mutableListOf<CapturedNotification>()

        fun getRecentNotifications(limit: Int = 5): List<CapturedNotification> {
            synchronized(recentNotifications) {
                return recentNotifications.take(limit)
            }
        }
    }
}
