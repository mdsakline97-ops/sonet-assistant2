package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.Settings
import com.sonet.assistant.data.model.ToolResult
import org.json.JSONArray
import org.json.JSONObject

class DeviceControlTool(private val context: Context) : Tool {
    override val name: String = "control_device"
    override val description: String = "Control device settings like flashlight (torch), volume, wifi settings, bluetooth settings, or check battery."

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("feature", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("torch", "volume_up", "volume_down", "mute", "wifi_settings", "bluetooth_settings", "battery")))
                    put("description", "The device feature to control")
                })
                put("state", JSONObject().apply {
                    put("type", "boolean")
                    put("description", "State for torch (true = on, false = off)")
                })
            })
            put("required", JSONArray(listOf("feature")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult {
        val feature = arguments.optString("feature")
        return when (feature) {
            "torch" -> {
                val state = arguments.optBoolean("state", true)
                try {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                    val id = cm?.cameraIdList?.firstOrNull() ?: return ToolResult(callId, name, "ক্যামেরা টর্চ সমর্থিত নয়।", false)
                    cm.setTorchMode(id, state)
                    ToolResult(callId, name, if (state) "টর্চ চালু করা হয়েছে।" else "টর্চ বন্ধ করা হয়েছে।")
                } catch (e: Exception) {
                    ToolResult(callId, name, "টর্চ নিয়ন্ত্রণে সমস্যা: ${e.message}", false)
                }
            }
            "volume_up" -> {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                ToolResult(callId, name, "ভলিউম বাড়ানো হয়েছে।")
            }
            "volume_down" -> {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                ToolResult(callId, name, "ভলিউম কমানো হয়েছে।")
            }
            "mute" -> {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                am?.ringerMode = AudioManager.RINGER_MODE_SILENT
                ToolResult(callId, name, "ফোন মিউট/সাইলেন্ট করা হয়েছে।")
            }
            "wifi_settings" -> {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(intent)
                ToolResult(callId, name, "ওয়াইফাই সেটিংস খোলা হয়েছে।")
            }
            "bluetooth_settings" -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(intent)
                ToolResult(callId, name, "ব্লুটুথ সেটিংস খোলা হয়েছে।")
            }
            "battery" -> {
                val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                val percent = if (level >= 0 && scale > 0) (level * 100) / scale else 50
                ToolResult(callId, name, "ব্যাটারি চার্জ: $percent%")
            }
            else -> ToolResult(callId, name, "অজানা কমান্ড: $feature", false)
        }
    }
}
