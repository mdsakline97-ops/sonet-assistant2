package com.sonet.assistant.data.repository

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.AppLanguage
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.model.WakeMethod
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class PreferencesRepository(private val context: Context) {

    private val prefs: SharedPreferences by lazy {
        try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                "sonet_encrypted_prefs",
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback to regular private prefs if KeyStore fails on some Android builds
            context.getSharedPreferences("sonet_fallback_prefs", Context.MODE_PRIVATE)
        }
    }

    private val _languageFlow = MutableStateFlow(getLanguage())
    val languageFlow: StateFlow<AppLanguage> = _languageFlow.asStateFlow()

    private val _wakeMethodFlow = MutableStateFlow(getWakeMethod())
    val wakeMethodFlow: StateFlow<WakeMethod> = _wakeMethodFlow.asStateFlow()

    private val _clapSensitivityFlow = MutableStateFlow(getClapSensitivity())
    val clapSensitivityFlow: StateFlow<Float> = _clapSensitivityFlow.asStateFlow()

    private val _continuousModeFlow = MutableStateFlow(isContinuousMode())
    val continuousModeFlow: StateFlow<Boolean> = _continuousModeFlow.asStateFlow()

    fun isOnboarded(): Boolean = prefs.getBoolean(KEY_ONBOARDED, false)
    fun setOnboarded(value: Boolean) = prefs.edit().putBoolean(KEY_ONBOARDED, value).apply()

    fun getLanguage(): AppLanguage {
        val code = prefs.getString(KEY_LANGUAGE, AppLanguage.BENGALI.code) ?: AppLanguage.BENGALI.code
        return AppLanguage.entries.find { it.code == code } ?: AppLanguage.BENGALI
    }

    fun setLanguage(lang: AppLanguage) {
        prefs.edit().putString(KEY_LANGUAGE, lang.code).apply()
        _languageFlow.value = lang
    }

    fun getWakeMethod(): WakeMethod {
        val id = prefs.getString(KEY_WAKE_METHOD, WakeMethod.CLAP.id) ?: WakeMethod.CLAP.id
        return WakeMethod.entries.find { it.id == id } ?: WakeMethod.CLAP
    }

    fun setWakeMethod(method: WakeMethod) {
        prefs.edit().putString(KEY_WAKE_METHOD, method.id).apply()
        _wakeMethodFlow.value = method
    }

    fun getClapSensitivity(): Float = prefs.getFloat(KEY_CLAP_SENSITIVITY, 0.65f)
    fun setClapSensitivity(value: Float) {
        prefs.edit().putFloat(KEY_CLAP_SENSITIVITY, value).apply()
        _clapSensitivityFlow.value = value
    }

    fun isContinuousMode(): Boolean = prefs.getBoolean(KEY_CONTINUOUS_MODE, true)
    fun setContinuousMode(value: Boolean) {
        prefs.edit().putBoolean(KEY_CONTINUOUS_MODE, value).apply()
        _continuousModeFlow.value = value
    }

    fun getVoicePitch(): Float = prefs.getFloat(KEY_VOICE_PITCH, 1.0f)
    fun setVoicePitch(value: Float) = prefs.edit().putFloat(KEY_VOICE_PITCH, value).apply()

    fun getSpeechRate(): Float = prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
    fun setSpeechRate(value: Float) = prefs.edit().putFloat(KEY_SPEECH_RATE, value).apply()

    fun isConfirmSensitive(): Boolean = prefs.getBoolean(KEY_CONFIRM_SENSITIVE, true)
    fun setConfirmSensitive(value: Boolean) = prefs.edit().putBoolean(KEY_CONFIRM_SENSITIVE, value).apply()

    fun getSystemPrompt(): String {
        return prefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
    }

    fun setSystemPrompt(prompt: String) {
        prefs.edit().putString(KEY_SYSTEM_PROMPT, prompt).apply()
    }

    fun getPrimaryProvider(): ProviderType {
        val name = prefs.getString(KEY_PRIMARY_PROVIDER, ProviderType.GEMINI.name) ?: ProviderType.GEMINI.name
        return try { ProviderType.valueOf(name) } catch (_: Exception) { ProviderType.GEMINI }
    }

    fun setPrimaryProvider(type: ProviderType) {
        prefs.edit().putString(KEY_PRIMARY_PROVIDER, type.name).apply()
    }

    fun getProviderConfigs(): List<AiProviderConfig> {
        val jsonStr = prefs.getString(KEY_PROVIDER_CONFIGS, null)
        if (jsonStr.isNullOrEmpty()) {
            return listOf(
                AiProviderConfig(ProviderType.GEMINI, "", ProviderType.GEMINI.defaultBaseUrl, ProviderType.GEMINI.defaultModel, true, 0),
                AiProviderConfig(ProviderType.OPENAI_COMPATIBLE, "", ProviderType.OPENAI_COMPATIBLE.defaultBaseUrl, ProviderType.OPENAI_COMPATIBLE.defaultModel, true, 1),
                AiProviderConfig(ProviderType.CLAUDE, "", ProviderType.CLAUDE.defaultBaseUrl, ProviderType.CLAUDE.defaultModel, true, 2)
            )
        }
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<AiProviderConfig>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val type = ProviderType.valueOf(obj.getString("type"))
                list.add(
                    AiProviderConfig(
                        type = type,
                        apiKey = obj.optString("apiKey", ""),
                        baseUrl = obj.optString("baseUrl", type.defaultBaseUrl),
                        modelName = obj.optString("modelName", type.defaultModel),
                        isEnabled = obj.optBoolean("isEnabled", true),
                        priority = obj.optInt("priority", i)
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveProviderConfigs(configs: List<AiProviderConfig>) {
        val array = JSONArray()
        for (cfg in configs) {
            val obj = JSONObject().apply {
                put("type", cfg.type.name)
                put("apiKey", cfg.apiKey)
                put("baseUrl", cfg.baseUrl)
                put("modelName", cfg.modelName)
                put("isEnabled", cfg.isEnabled)
                put("priority", cfg.priority)
            }
            array.put(obj)
        }
        prefs.edit().putString(KEY_PROVIDER_CONFIGS, array.toString()).apply()
    }

    fun updateProviderConfig(updated: AiProviderConfig) {
        val current = getProviderConfigs().toMutableList()
        val index = current.indexOfFirst { it.type == updated.type }
        if (index != -1) {
            current[index] = updated
        } else {
            current.add(updated)
        }
        saveProviderConfigs(current)
    }

    companion object {
        private const val KEY_ONBOARDED = "key_onboarded"
        private const val KEY_LANGUAGE = "key_language"
        private const val KEY_WAKE_METHOD = "key_wake_method"
        private const val KEY_CLAP_SENSITIVITY = "key_clap_sensitivity"
        private const val KEY_CONTINUOUS_MODE = "key_continuous_mode"
        private const val KEY_VOICE_PITCH = "key_voice_pitch"
        private const val KEY_SPEECH_RATE = "key_speech_rate"
        private const val KEY_CONFIRM_SENSITIVE = "key_confirm_sensitive"
        private const val KEY_SYSTEM_PROMPT = "key_system_prompt"
        private const val KEY_PRIMARY_PROVIDER = "key_primary_provider"
        private const val KEY_PROVIDER_CONFIGS = "key_provider_configs"

        val DEFAULT_SYSTEM_PROMPT = """
            You are Sonet, a friendly, ultra-capable personal voice assistant living on the user's Android phone.
            Always reply in the user's spoken language (Bengali by default), keeping responses short, concise, and natural because your answers will be spoken aloud via Text-to-Speech.
            Use the provided tools to take real device actions (calls, messages, alarms, apps, settings, search, etc.).
            Always ask for user confirmation before sensitive actions (like sending messages, placing calls, deleting data, or making transactions).
            When asked something factual, current, or unknown, use web search and provide a brief conversational summary with sources.
            If you cannot perform an action, explain clearly and politely in Bengali, and suggest an alternative.
            Remember and use the user's saved preferences and personal facts.
        """.trimIndent()
    }
}
