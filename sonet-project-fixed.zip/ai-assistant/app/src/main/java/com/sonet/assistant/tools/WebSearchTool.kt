package com.sonet.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sonet.assistant.data.model.ToolResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class WebSearchTool(private val context: Context) : Tool {
    override val name: String = "web_search"
    override val description: String = "Search the web or Wikipedia for factual, current information or open a URL."

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override fun getParametersSchema(): JSONObject {
        return JSONObject().apply {
            put("type", "object")
            put("properties", JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Search query or question")
                })
                put("open_url", JSONObject().apply {
                    put("type", "string")
                    put("description", "Optional URL to directly open in browser")
                })
            })
            put("required", JSONArray(listOf("query")))
        }
    }

    override suspend fun execute(callId: String, arguments: JSONObject): ToolResult = withContext(Dispatchers.IO) {
        val openUrl = arguments.optString("open_url", "").trim()
        if (openUrl.isNotEmpty()) {
            val validUrl = if (!openUrl.startsWith("http://") && !openUrl.startsWith("https://")) "https://$openUrl" else openUrl
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return@withContext ToolResult(callId, name, "ব্রাউজারে $validUrl খোলা হয়েছে।")
        }

        val query = arguments.optString("query", "").trim()
        if (query.isEmpty()) {
            return@withContext ToolResult(callId, name, "অনুসন্ধানের বিষয়বস্তু পাওয়া যায়নি।", false)
        }

        val encoded = URLEncoder.encode(query, "UTF-8")

        // 1. DuckDuckGo Instant Answer
        try {
            val ddgReq = Request.Builder()
                .url("https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1")
                .header("User-Agent", "SonetAssistant/1.0")
                .build()
            val ddgResp = httpClient.newCall(ddgReq).execute()
            if (ddgResp.isSuccessful) {
                val body = ddgResp.body?.string() ?: ""
                val json = JSONObject(body)
                val abstractText = json.optString("AbstractText", "")
                val source = json.optString("AbstractSource", "DuckDuckGo")
                if (abstractText.isNotEmpty()) {
                    return@withContext ToolResult(callId, name, "$abstractText (সূত্র: $source)")
                }
            }
        } catch (_: Exception) {}

        // 2. Wikipedia Search (Bengali or English based on query)
        try {
            val isBengali = query.any { it.code in 0x0980..0x09FF }
            val wikiHost = if (isBengali) "bn.wikipedia.org" else "en.wikipedia.org"
            val wikiReq = Request.Builder()
                .url("https://$wikiHost/w/api.php?action=query&list=search&srsearch=$encoded&utf8=&format=json")
                .header("User-Agent", "SonetAssistant/1.0")
                .build()
            val wikiResp = httpClient.newCall(wikiReq).execute()
            if (wikiResp.isSuccessful) {
                val body = wikiResp.body?.string() ?: ""
                val json = JSONObject(body)
                val searchList = json.optJSONObject("query")?.optJSONArray("search")
                if (searchList != null && searchList.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until minOf(searchList.length(), 2)) {
                        val item = searchList.getJSONObject(i)
                        val title = item.optString("title")
                        val snippet = item.optString("snippet").replace("<[^>]*>".toRegex(), "")
                        sb.append("• $title: $snippet\n")
                    }
                    return@withContext ToolResult(callId, name, sb.toString().trim() + " (উইকিপিডিয়া)")
                }
            }
        } catch (_: Exception) {}

        ToolResult(callId, name, "\"$query\" সম্পর্কে সরাসরি কোনো সারসংক্ষেপ পাওয়া যায়নি।")
    }
}
