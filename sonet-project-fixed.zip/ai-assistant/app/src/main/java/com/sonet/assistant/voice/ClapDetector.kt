package com.sonet.assistant.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.sonet.assistant.util.PermissionUtils
import kotlinx.coroutines.*
import kotlin.math.sqrt

class ClapDetector(
    private val context: Context,
    private val onDoubleClapDetected: () -> Unit
) {
    interface ClapTestListener {
        fun onAmplitudeUpdate(normalizedAmplitude: Float)
        fun onSingleClapDetected()
    }

    var testListener: ClapTestListener? = null
    var sensitivity: Float = 0.65f // 0.1 (hard) to 1.0 (easy)

    private var audioRecord: AudioRecord? = null
    private var isListening = false
    private var recordingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var lastClapTime = 0L

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val MIN_CLAP_INTERVAL_MS = 200L
        private const val MAX_CLAP_INTERVAL_MS = 950L
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (isListening) return
        if (!PermissionUtils.hasRecordAudio(context)) return

        try {
            val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            val bufferSize = (minBufferSize * 2).coerceAtLeast(1024)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                audioRecord?.release()
                audioRecord = null
                return
            }

            audioRecord?.startRecording()
            isListening = true

            recordingJob = scope.launch {
                val buffer = ShortArray(bufferSize)
                var ambientEnergy = 500.0

                while (isActive && isListening) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                    if (read > 0) {
                        var sum = 0.0
                        for (i in 0 until read) {
                            sum += buffer[i] * buffer[i]
                        }
                        val rms = sqrt(sum / read)

                        // Smooth ambient background noise tracker
                        ambientEnergy = 0.96 * ambientEnergy + 0.04 * rms

                        // Dynamic spike threshold based on sensitivity slider
                        // High sensitivity -> lower multiplier (e.g. 4x ambient), Low sensitivity -> higher multiplier (e.g. 10x ambient)
                        val multiplier = 12.0 - (sensitivity.coerceIn(0.1f, 1.0f) * 8.0)
                        val clapThreshold = (ambientEnergy * multiplier).coerceAtLeast(2800.0)

                        val normalizedLevel = (rms / 15000.0).toFloat().coerceIn(0f, 1f)
                        testListener?.onAmplitudeUpdate(normalizedLevel)

                        if (rms > clapThreshold) {
                            val now = System.currentTimeMillis()
                            testListener?.onSingleClapDetected()

                            val timeSinceLast = now - lastClapTime
                            if (timeSinceLast in MIN_CLAP_INTERVAL_MS..MAX_CLAP_INTERVAL_MS) {
                                // Double clap registered!
                                lastClapTime = 0L
                                withContext(Dispatchers.Main) {
                                    onDoubleClapDetected()
                                }
                                delay(600) // Debounce after trigger
                            } else {
                                lastClapTime = now
                            }
                        }
                    }
                    delay(20)
                }
            }
        } catch (_: Exception) {
            stop()
        }
    }

    fun stop() {
        isListening = false
        recordingJob?.cancel()
        recordingJob = null
        try {
            if (audioRecord?.state == AudioRecord.STATE_INITIALIZED) {
                audioRecord?.stop()
            }
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    fun isRunning(): Boolean = isListening
}
