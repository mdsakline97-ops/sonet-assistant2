package com.sonet.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonet.assistant.data.repository.CrashLogManager
import com.sonet.assistant.tools.DeviceControlTool
import com.sonet.assistant.tools.WebSearchTool
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.ErrorRed
import com.sonet.assistant.ui.theme.SurfaceDark
import com.sonet.assistant.voice.SoundFeedbackManager
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun DiagnosticsScreen(
    crashLogger: CrashLogManager
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var logs by remember { mutableStateOf(crashLogger.getLogs()) }
    var testResultText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "লগ ও ডায়াগনস্টিকস",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "সিস্টেম ক্র্যাশ, এআই এপিআই ত্রুটি এবং হার্ডওয়্যার টুলস পরীক্ষা করুন",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        // Hardware test buttons
        Text(text = "দ্রুত টুলস পরীক্ষা", color = CyanPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    val sound = SoundFeedbackManager()
                    sound.playWakeBeep()
                    testResultText = "বিপ সাউন্ড বাজানো হয়েছে।"
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = "সাউন্ড টেস্ট", fontSize = 12.sp, color = Color.White)
            }
            OutlinedButton(
                onClick = {
                    coroutineScope.launch {
                        val deviceTool = DeviceControlTool(context)
                        val res = deviceTool.execute("test", JSONObject().apply {
                            put("feature", "torch")
                            put("state", true)
                        })
                        testResultText = res.resultText
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = "টর্চ টেস্ট", fontSize = 12.sp, color = Color.White)
            }
            OutlinedButton(
                onClick = {
                    coroutineScope.launch {
                        val searchTool = WebSearchTool(context)
                        val res = searchTool.execute("test", JSONObject().apply {
                            put("query", "Bangladesh")
                        })
                        testResultText = res.resultText
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = "সার্চ টেস্ট", fontSize = 12.sp, color = Color.White)
            }
        }

        if (testResultText.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = testResultText, color = CyanPrimary, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "সিস্টেম ও ক্র্যাশ লগ", color = CyanPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Row {
                IconButton(onClick = { logs = crashLogger.getLogs() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                }
                IconButton(onClick = {
                    crashLogger.clearLogs()
                    logs = crashLogger.getLogs()
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear", tint = ErrorRed)
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 200.dp, max = 360.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = logs.ifEmpty { "কোনো ত্রুটি নেই। সবকিছু স্বাভাবিক চলছে!" },
                    color = if (logs.contains("ত্রুটি") || logs.contains("Exception")) Color(0xFFFCA5A5) else Color(0xFFE2E8F0),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
