package com.sonet.assistant.providers

import com.sonet.assistant.data.model.AiProviderConfig
import com.sonet.assistant.data.model.ChatMessage
import com.sonet.assistant.data.model.ProviderType
import com.sonet.assistant.data.model.ToolCall

data class ProviderResponse(
    val content: String,
    val toolCalls: List<ToolCall> = emptyList(),
    val rawJson: String = ""
)

interface AiProvider {
    val type: ProviderType

    suspend fun chat(
        config: AiProviderConfig,
        systemPrompt: String,
        messages: List<ChatMessage>,
        toolsJson: Any?
    ): ProviderResponse

    suspend fun listModels(config: AiProviderConfig): List<String>

    suspend fun testConnection(config: AiProviderConfig): Pair<Boolean, String>
}
