package com.sonet.assistant.service

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.sonet.assistant.data.model.AssistantState
import com.sonet.assistant.util.PermissionUtils

class OverlayManager(
    private val context: Context,
    private val onStopClicked: () -> Unit,
    private val onConfirmClicked: (Boolean) -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlayView: View? = null
    private var isShowing = false

    private var statusTextView: TextView? = null
    private var transcriptTextView: TextView? = null
    private var responseTextView: TextView? = null
    private var confirmationContainer: LinearLayout? = null
    private var confirmPromptTextView: TextView? = null
    private var progressBar: ProgressBar? = null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (isShowing || !PermissionUtils.hasOverlay(context)) return

        mainHandler.post {
            try {
                val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.BOTTOM
                    y = 60
                }

                val root = FrameLayout(context).apply {
                    setPadding(32, 16, 32, 48)
                }

                // Card container
                val card = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(40, 36, 40, 36)
                    val bg = GradientDrawable().apply {
                        setColor(Color.parseColor("#EE131B2E"))
                        cornerRadius = 48f
                        setStroke(3, Color.parseColor("#4400E5FF"))
                    }
                    background = bg
                    elevation = 20f
                }

                // Top bar: title + close
                val topBar = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val titleView = TextView(context).apply {
                    text = "সোনেট (Sonet AI)"
                    setTextColor(Color.parseColor("#00E5FF"))
                    textSize = 17f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }

                val closeBtn = TextView(context).apply {
                    text = "✕"
                    setTextColor(Color.parseColor("#94A3B8"))
                    textSize = 20f
                    setPadding(20, 10, 20, 10)
                    setOnClickListener {
                        hide()
                        onStopClicked()
                    }
                }
                topBar.addView(titleView)
                topBar.addView(closeBtn)
                card.addView(topBar)

                // Status text & spinner
                val statusRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 16, 0, 12)
                }

                progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleSmall).apply {
                    visibility = View.VISIBLE
                    layoutParams = LinearLayout.LayoutParams(40, 40).apply { rightMargin = 16 }
                }
                statusTextView = TextView(context).apply {
                    text = "শুনছি…"
                    setTextColor(Color.parseColor("#38BDF8"))
                    textSize = 14f
                }
                statusRow.addView(progressBar)
                statusRow.addView(statusTextView)
                card.addView(statusRow)

                // User Transcript
                transcriptTextView = TextView(context).apply {
                    text = ""
                    setTextColor(Color.parseColor("#F1F5F9"))
                    textSize = 16f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(0, 8, 0, 8)
                }
                card.addView(transcriptTextView)

                // Assistant Response
                responseTextView = TextView(context).apply {
                    text = ""
                    setTextColor(Color.parseColor("#CBD5E1"))
                    textSize = 15f
                    setPadding(0, 8, 0, 16)
                }
                card.addView(responseTextView)

                // Confirmation container (hidden by default)
                confirmationContainer = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                    setPadding(0, 12, 0, 8)
                }
                confirmPromptTextView = TextView(context).apply {
                    setTextColor(Color.parseColor("#FBBF24"))
                    textSize = 14f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(0, 0, 0, 16)
                }
                val btnRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                }
                val yesBtn = TextView(context).apply {
                    text = "হ্যাঁ, করুন"
                    setTextColor(Color.BLACK)
                    setBackgroundColor(Color.parseColor("#10B981"))
                    setPadding(32, 16, 32, 16)
                    setOnClickListener {
                        confirmationContainer?.visibility = View.GONE
                        onConfirmClicked(true)
                    }
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        rightMargin = 16
                    }
                    gravity = Gravity.CENTER
                }
                val noBtn = TextView(context).apply {
                    text = "বাতিল"
                    setTextColor(Color.WHITE)
                    setBackgroundColor(Color.parseColor("#EF4444"))
                    setPadding(32, 16, 32, 16)
                    setOnClickListener {
                        confirmationContainer?.visibility = View.GONE
                        onConfirmClicked(false)
                    }
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    gravity = Gravity.CENTER
                }
                btnRow.addView(yesBtn)
                btnRow.addView(noBtn)
                confirmationContainer?.addView(confirmPromptTextView)
                confirmationContainer?.addView(btnRow)
                card.addView(confirmationContainer)

                root.addView(card)
                overlayView = root

                windowManager?.addView(root, params)
                isShowing = true
            } catch (_: Exception) {}
        }
    }

    fun updateState(state: AssistantState) {
        mainHandler.post {
            statusTextView?.text = when (state) {
                AssistantState.LISTENING -> "শুনছি…"
                AssistantState.THINKING -> "ভাবছি…"
                AssistantState.SPEAKING -> "বলছি…"
                AssistantState.IDLE -> "প্রস্তুত"
                AssistantState.ERROR -> "ত্রুটি"
            }
            progressBar?.visibility = if (state == AssistantState.IDLE) View.GONE else View.VISIBLE
        }
    }

    fun updateTranscript(text: String) {
        mainHandler.post {
            transcriptTextView?.text = text
        }
    }

    fun updateResponse(text: String) {
        mainHandler.post {
            responseTextView?.text = text
        }
    }

    fun requestConfirmation(prompt: String) {
        mainHandler.post {
            confirmPromptTextView?.text = prompt
            confirmationContainer?.visibility = View.VISIBLE
        }
    }

    fun hide() {
        if (!isShowing) return
        mainHandler.post {
            try {
                overlayView?.let { windowManager?.removeView(it) }
            } catch (_: Exception) {}
            overlayView = null
            isShowing = false
        }
    }

    fun isVisible(): Boolean = isShowing
}
