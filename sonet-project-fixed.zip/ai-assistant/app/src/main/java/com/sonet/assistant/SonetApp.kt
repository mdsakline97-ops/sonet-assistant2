package com.sonet.assistant

import android.app.Application
import android.content.Intent
import com.sonet.assistant.data.repository.CrashLogManager
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.service.SonetForegroundService
import com.sonet.assistant.util.PermissionUtils

class SonetApp : Application() {

    lateinit var crashLogger: CrashLogManager
        private set
    lateinit var prefsRepo: PreferencesRepository
        private set

    override fun onCreate() {
        super.onCreate()
        crashLogger = CrashLogManager(this)
        prefsRepo = PreferencesRepository(this)

        // Global crash handler to log uncaught exceptions
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            crashLogger.log("UNCAUGHT_CRASH", "ক্র্যাশ থ্রেড: ${thread.name}, বার্তা: ${throwable.message}", throwable)
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // Auto start foreground service if already onboarded
        if (prefsRepo.isOnboarded() && PermissionUtils.hasRecordAudio(this)) {
            val serviceIntent = Intent(this, SonetForegroundService::class.java).apply {
                action = SonetForegroundService.ACTION_START_SERVICE
            }
            try {
                startForegroundService(serviceIntent)
            } catch (_: Exception) {}
        }
    }
}
