package com.sonet.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonet.assistant.R
import com.sonet.assistant.data.model.AppLanguage
import com.sonet.assistant.data.model.WakeMethod
import com.sonet.assistant.data.repository.PreferencesRepository
import com.sonet.assistant.ui.theme.CyanPrimary
import com.sonet.assistant.ui.theme.DarkBackground
import com.sonet.assistant.ui.theme.PurpleAccent
import com.sonet.assistant.ui.theme.SurfaceDark

@Composable
fun SettingsScreen(
    prefsRepo: PreferencesRepository,
    onNavigateToProviders: () -> Unit,
    onNavigateToClapTester: () -> Unit,
    onNavigateToPermissions: () -> Unit
) {
    var language by remember { mutableStateOf(prefsRepo.getLanguage()) }
    var wakeMethod by remember { mutableStateOf(prefsRepo.getWakeMethod()) }
    var continuousMode by remember { mutableStateOf(prefsRepo.isContinuousMode()) }
    var confirmSensitive by remember { mutableStateOf(prefsRepo.isConfirmSensitive()) }
    var speechRate by remember { mutableFloatStateOf(prefsRepo.getSpeechRate()) }
    var voicePitch by remember { mutableFloatStateOf(prefsRepo.getVoicePitch()) }

    var showPromptDialog by remember { mutableStateOf(false) }
    var systemPrompt by remember { mutableStateOf(prefsRepo.getSystemPrompt()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = stringResource(R.string.settings_title),
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        // AI Provider Shortcut Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = PurpleAccent.copy(alpha = 0.2f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToProviders() }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(text = "এআই ইঞ্জিন ও এপিআই কি", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(text = "Gemini, Groq, DeepSeek কনফিগার করুন", color = Color(0xFF94A3B8), fontSize = 13.sp)
                    }
                }
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // General Section
        Text(text = "সাধারণ সেটিংস", color = CyanPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(10.dp))

        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Language
                Text(text = "অ্যাপের ভাষা", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = language == lang,
                            onClick = {
                                language = lang
                                prefsRepo.setLanguage(lang)
                            },
                            label = { Text(lang.displayName) }
                        )
                    }
                }

                Divider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 12.dp))

                // Wake Method
                Text(text = "জাগানোর পদ্ধতি", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = wakeMethod == WakeMethod.CLAP,
                        onClick = {
                            wakeMethod = WakeMethod.CLAP
                            prefsRepo.setWakeMethod(WakeMethod.CLAP)
                        },
                        label = { Text("তালি (Clap)") }
                    )
                    FilterChip(
                        selected = wakeMethod == WakeMethod.BUTTON_ONLY,
                        onClick = {
                            wakeMethod = WakeMethod.BUTTON_ONLY
                            prefsRepo.setWakeMethod(WakeMethod.BUTTON_ONLY)
                        },
                        label = { Text("বোতাম / টাইল") }
                    )
                }

                if (wakeMethod == WakeMethod.CLAP) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onNavigateToClapTester,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.WavingHand, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "তালি শনাক্তকরণ পরীক্ষা ও সংবেদনশীলতা", color = CyanPrimary, fontSize = 13.sp)
                    }
                }

                Divider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 12.dp))

                // Continuous mode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "ধারাবাহিক কথোপকথন মোড", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(text = "উত্তর দেওয়ার পর স্বয়ংক্রিয়ভাবে আবার শুনবে", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    }
                    Switch(
                        checked = continuousMode,
                        onCheckedChange = {
                            continuousMode = it
                            prefsRepo.setContinuousMode(it)
                        }
                    )
                }

                Divider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 12.dp))

                // Confirm sensitive actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "সংবেদনশীল কাজের নিশ্চিতকরণ", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(text = "কল করা বা মেসেজ পাঠানোর আগে অনুমতি চাইবে", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    }
                    Switch(
                        checked = confirmSensitive,
                        onCheckedChange = {
                            confirmSensitive = it
                            prefsRepo.setConfirmSensitive(it)
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Voice Section
        Text(text = "ভয়েস ও স্পিচ টিউনিং", color = CyanPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(10.dp))

        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "কথা বলার গতি: ${(speechRate * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
                Slider(
                    value = speechRate,
                    onValueChange = {
                        speechRate = it
                        prefsRepo.setSpeechRate(it)
                    },
                    valueRange = 0.6f..1.6f
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(text = "ভয়েসের পিচ: ${(voicePitch * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
                Slider(
                    value = voicePitch,
                    onValueChange = {
                        voicePitch = it
                        prefsRepo.setVoicePitch(it)
                    },
                    valueRange = 0.6f..1.6f
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // System Prompt & Permissions
        OutlinedButton(
            onClick = { showPromptDialog = true },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "সিস্টেম প্রম্পট কাস্টমাইজ করুন", color = Color.White)
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = onNavigateToPermissions,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "অনুমতি যাচাই করুন", color = Color.White)
        }
    }

    if (showPromptDialog) {
        AlertDialog(
            onDismissRequest = { showPromptDialog = false },
            containerColor = SurfaceDark,
            title = { Text("সিস্টেম প্রম্পট", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = { systemPrompt = it },
                    modifier = Modifier.fillMaxWidth().height(220.dp),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        prefsRepo.setSystemPrompt(systemPrompt)
                        showPromptDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                ) {
                    Text("সংরক্ষণ", color = DarkBackground)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPromptDialog = false }) {
                    Text("বাতিল", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}
