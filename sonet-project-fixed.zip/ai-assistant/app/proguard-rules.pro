# Proguard rules for Sonet
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
